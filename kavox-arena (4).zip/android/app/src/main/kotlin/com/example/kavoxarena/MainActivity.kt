package com.example.kavoxarena

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
