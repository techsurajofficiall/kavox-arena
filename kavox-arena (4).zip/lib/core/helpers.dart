import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'theme.dart';

final sb = Supabase.instance.client;
typedef Json = Map<String, dynamic>;

// ───────── Numbers ─────────
double dbl(dynamic v) => v is num ? v.toDouble() : (double.tryParse('$v') ?? 0.0);
int toInt(dynamic v) => v is num ? v.toInt() : (int.tryParse('$v') ?? 0);

String money(dynamic v) {
  final d = dbl(v);
  return d == d.roundToDouble() ? d.toInt().toString() : d.toStringAsFixed(2);
}

// ───────── Time ─────────
DateTime? parseT(dynamic v) => v == null ? null : DateTime.tryParse('$v')?.toLocal();

String fmtTime(dynamic iso) {
  final d = parseT(iso);
  if (d == null) return '-';
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  return '${d.day} ${m[d.month - 1]}, $h:${d.minute.toString().padLeft(2, '0')} ${d.hour >= 12 ? 'PM' : 'AM'}';
}

// ContestsScreen aur TournamentDetailScreen ke liye formatDt function
String formatDt(dynamic dt) {
  if (dt == null) return 'TBA';
  try {
    final parsed = DateTime.parse(dt.toString()).toLocal();
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    final h = parsed.hour % 12 == 0 ? 12 : parsed.hour % 12;
    return '${parsed.day} ${m[parsed.month - 1]}, $h:${parsed.minute.toString().padLeft(2, '0')} ${parsed.hour >= 12 ? 'PM' : 'AM'}';
  } catch (_) {
    return dt.toString();
  }
}

// ───────── Errors + messages ─────────
String errText(Object e) {
  String msg;
  if (e is PostgrestException) {
    msg = e.message;
  } else if (e is AuthException) {
    msg = e.message;
  } else {
    msg = '$e';
  }
  if (msg.contains('Database error saving new user')) {
    return 'Ye username ya mobile number pehle se registered hai';
  }
  return msg;
}

void snack(BuildContext c, String msg) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(msg)));
}

// ───────── Tournament helpers ─────────
Color statusColor(String s) {
  switch (s) {
    case 'ongoing':
      return kRed;
    case 'completed':
    case 'cancelled':
      return Colors.grey;
    default:
      return kGreen;
  }
}

String statusLabel(String s) => s == 'ongoing' ? 'LIVE' : s.toUpperCase();

IconData catIcon(String n) {
  final u = n.toUpperCase();
  if (u.contains('SURVIVAL')) return Icons.public;
  if (u.contains('PER KILL')) return Icons.gps_fixed;
  if (u.contains('LONE')) return Icons.pets;
  if (u.contains('CLASH')) return Icons.groups;
  if (u.contains('FREE')) return Icons.card_giftcard;
  return Icons.sports_esports;
}

Map<String, dynamic>? prizeMapOf(dynamic pb) {
  if (pb == null) return null;
  if (pb is Map) return Map<String, dynamic>.from(pb);
  if (pb is String && pb.isNotEmpty) {
    try {
      final d = jsonDecode(pb);
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
  }
  return null;
}

bool isCredit(String type) => type == 'Add Money' || type == 'Winning' || type == 'Refund';

// ───────── Avatar ─────────
const kAvatarIcons = [
  Icons.face,
  Icons.sports_esports,
  Icons.whatshot,
  Icons.rocket_launch,
  Icons.bolt,
  Icons.shield,
];

int avatarIndex(dynamic a) {
  final m = RegExp(r'(\d)').firstMatch('$a');
  final n = m == null ? 1 : int.parse(m.group(1)!);
  return (n - 1).clamp(0, 5).toInt();
}

Widget avatarWidget(dynamic a, double size) {
  final i = avatarIndex(a);
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(shape: BoxShape.circle, color: kTileColors[i]),
    child: Icon(kAvatarIcons[i], color: Colors.white, size: size * 0.55),
  );
}