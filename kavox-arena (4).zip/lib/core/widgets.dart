import 'dart:async';
import 'package:flutter/material.dart';

import 'helpers.dart';
import 'theme.dart';

// ───────── Basic building blocks ─────────

Widget card({
  required Widget child,
  EdgeInsets padding = const EdgeInsets.all(16),
  VoidCallback? onTap,
}) {
  final box = Container(
    width: double.infinity,
    padding: padding,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: kBorder),
      boxShadow: [
        BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4)),
      ],
    ),
    child: child,
  );
  if (onTap == null) return box;
  return GestureDetector(onTap: onTap, child: box);
}

Widget pill(String t, Color c) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
        color: c.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
    child: Text(t,
        style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w800)),
  );
}

Widget sectionTitle(String t) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(4, 20, 4, 10),
    child: Text(
      t.toUpperCase(),
      style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.4,
          color: kGrey),
    ),
  );
}

Widget kv(String k, String v) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(
      children: [
        Text(k,
            style: const TextStyle(color: kGrey, fontWeight: FontWeight.w600)),
        const Spacer(),
        Text(v,
            style: const TextStyle(color: kInk, fontWeight: FontWeight.w800)),
      ],
    ),
  );
}

Widget miniInfo(String label, String value) {
  return Expanded(
    child: card(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Text(label.toUpperCase(),
              style: const TextStyle(
                  fontSize: 10, color: kGrey, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(value,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontWeight: FontWeight.w800, fontSize: 13, color: kInk)),
        ],
      ),
    ),
  );
}

/// Header ka sone wala coin + balance chip (PHP jaisa).
Widget coinChip(dynamic amount, {VoidCallback? onTap, bool dark = false}) {
  final chip = Container(
    padding: const EdgeInsets.fromLTRB(4, 4, 16, 4),
    decoration: BoxDecoration(
      color: dark ? kInk : Colors.white,
      borderRadius: BorderRadius.circular(30),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 32,
          height: 32,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFDE047), Color(0xFFF59E0B)],
            ),
          ),
          child: const Text('₹',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 18)),
        ),
        const SizedBox(width: 8),
        Text(
          money(amount),
          style: TextStyle(
            color: dark ? Colors.white : kInk,
            fontWeight: FontWeight.w800,
            fontSize: 18,
            letterSpacing: 0.5,
          ),
        ),
      ],
    ),
  );
  if (onTap == null) return chip;
  return GestureDetector(onTap: onTap, child: chip);
}

// ───────── Inputs + buttons ─────────

class Field extends StatelessWidget {
  final TextEditingController c;
  final String hint;
  final IconData icon;
  final bool obscure;
  final TextInputType? type;
  final Widget? suffix;

  const Field(this.c, this.hint, this.icon,
      {super.key, this.obscure = false, this.type, this.suffix});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kBorder, width: 1.5),
      ),
      child: TextField(
        controller: c,
        obscureText: obscure,
        keyboardType: type,
        cursorColor: kIndigo,
        style: const TextStyle(
            fontSize: 16, color: kInk, fontWeight: FontWeight.w500),
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: hint,
          hintStyle: const TextStyle(
              color: Color(0xFF9CA3AF), fontWeight: FontWeight.w500),
          prefixIcon: Icon(icon, color: const Color(0xFF9CA3AF)),
          suffixIcon: suffix,
          contentPadding: const EdgeInsets.symmetric(vertical: 18),
        ),
      ),
    );
  }
}

class GradButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool busy;
  final List<Color> colors;

  const GradButton({
    super.key,
    required this.label,
    required this.onTap,
    this.busy = false,
    this.colors = const [kIndigo, kViolet],
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: (onTap == null && !busy) ? 0.5 : 1.0,
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: colors),
          borderRadius: BorderRadius.circular(27),
          boxShadow: [
            BoxShadow(
                color: colors.first.withOpacity(0.3),
                blurRadius: 16,
                offset: const Offset(0, 6)),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(27),
            onTap: busy ? null : onTap,
            child: Center(
              child: busy
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: Colors.white),
                    )
                  : Text(
                      label,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        fontSize: 15,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

// ───────── Countdown ─────────

class Countdown extends StatefulWidget {
  final DateTime target;
  const Countdown({super.key, required this.target});
  @override
  State<Countdown> createState() => _CountdownState();
}

class _CountdownState extends State<Countdown> {
  Timer? _t;
  Duration _left = Duration.zero;

  @override
  void initState() {
    super.initState();
    _tick();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(_tick);
    });
  }

  void _tick() {
    _left = widget.target.difference(DateTime.now());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_left.isNegative) {
      return const Text('MATCH STARTED',
          style: TextStyle(
              color: kRed, fontWeight: FontWeight.w800, fontSize: 14));
    }
    final d = _left.inDays;
    final h = _left.inHours % 24;
    final m = _left.inMinutes % 60;
    final s = _left.inSeconds % 60;
    return Text('${d}d ${h}h ${m}m ${s}s',
        style: const TextStyle(
            color: kIndigo, fontWeight: FontWeight.w800, fontSize: 15));
  }
}

// ───────── Tournament card ─────────
// Tap karne par kya hoga, wo onTap se aata hai (details screen alag file me hai).

Widget tournamentCard(Json t, {String? footer, VoidCallback? onTap}) {
  final status = '${t['status']}';
  final joined = toInt(t['joined_count']);
  final maxSlots = toInt(t['max_slots']);
  final perKill = dbl(t['per_kill']);
  final fee = dbl(t['entry_fee']);
  final prize = dbl(t['prize_pool']);
  final prizeText = perKill > 0
      ? '₹${money(perKill)} / kill'
      : (prize > 0 ? 'Prize ₹${money(prize)}' : 'Prize list inside');

  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: card(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('${t['title']}',
                    style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: kInk)),
              ),
              pill(statusLabel(status), statusColor(status)),
            ],
          ),
          const SizedBox(height: 4),
          Text(
              '${t['game_mode']} • ${t['map_name']} • ${fmtTime(t['start_time'])}',
              style: const TextStyle(color: kGrey, fontSize: 13)),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.emoji_events, size: 18, color: kAmber),
              const SizedBox(width: 4),
              Text(prizeText,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, color: kInk)),
              const Spacer(),
              Text(fee == 0 ? 'FREE' : 'Entry ₹${money(fee)}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, color: kIndigo)),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: maxSlots == 0 ? 0.0 : joined / maxSlots,
              minHeight: 6,
              backgroundColor: kBorder,
              valueColor: const AlwaysStoppedAnimation<Color>(kIndigo),
            ),
          ),
          const SizedBox(height: 4),
          Text('$joined / $maxSlots joined',
              style: const TextStyle(fontSize: 12, color: kGrey)),
          if (footer != null) ...[
            const SizedBox(height: 8),
            Text(footer,
                style: const TextStyle(
                    color: kIndigo, fontWeight: FontWeight.w700, fontSize: 13)),
          ],
        ],
      ),
    ),
  );
}
