import 'package:flutter/material.dart';

// ───────── Colors (PHP app jaisi) ─────────
const kIndigo = Color(0xFF4F46E5);
const kViolet = Color(0xFF7C3AED);
const kInk = Color(0xFF0F172A);
const kGrey = Color(0xFF6B7280);
const kBg = Color(0xFFF8F9FC);
const kBorder = Color(0xFFE5E7EB);
const kSlate = Color(0xFF64748B); // header aur neeche ka nav
const kYellow = Color(0xFFFBBF24); // nav me selected item
const kGreen = Color(0xFF059669);
const kDot = Color(0xFF10B981); // game card ka green dot
const kAmber = Color(0xFFD97706);
const kRed = Color(0xFFDC2626);

const kTileColors = [
  Color(0xFF4F46E5),
  Color(0xFF7C3AED),
  Color(0xFFEA580C),
  Color(0xFF0891B2),
  Color(0xFFD97706),
  Color(0xFF059669),
  Color(0xFFDB2777),
];

ThemeData kvxTheme() {
  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: kIndigo),
    scaffoldBackgroundColor: kBg,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.white,
      foregroundColor: kInk,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      shape: Border(bottom: BorderSide(color: kBorder)),
      titleTextStyle: TextStyle(
        color: kInk,
        fontSize: 18,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.5,
      ),
    ),
  );
}