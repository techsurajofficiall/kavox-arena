import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';

class JoinSlotScreen extends StatefulWidget {
  final String tournamentId;
  final Map<String, dynamic> tournamentData;
  final VoidCallback onJoined;

  const JoinSlotScreen({
    super.key,
    required this.tournamentId,
    required this.tournamentData,
    required this.onJoined,
  });

  @override
  State<JoinSlotScreen> createState() => _JoinSlotScreenState();
}

class _JoinSlotScreenState extends State<JoinSlotScreen> {
  int _currentStep = 1;
  bool _loading = false;
  bool _fetchingData = true;

  double _walletBalance = 0.0;
  double _entryFee = 0.0;

  int _maxTeams = 48;
  List<String> _positions = ['1'];
  Set<String> _bookedSlots = {};

  String? _selectedTeamSlot; 
  String _selectedTeamName = '';
  String _selectedPosName = '';

  final TextEditingController _ignController = TextEditingController();
  final TextEditingController _ffIdController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _calculateSlotStructure();
    _fetchUserDataAndBookings();
  }

  @override
  void dispose() {
    _ignController.dispose();
    _ffIdController.dispose();
    super.dispose();
  }

  void _calculateSlotStructure() {
    final title = (widget.tournamentData['title'] ?? '').toString().toLowerCase();
    final category = (widget.tournamentData['category'] ?? widget.tournamentData['game_type'] ?? '').toString().toLowerCase();
    final teamType = (widget.tournamentData['game_mode'] ?? widget.tournamentData['mode'] ?? widget.tournamentData['team_type'] ?? '').toString().toLowerCase();
    
    final combined = '$title $category $teamType';

    if (combined.contains('4v4')) {
      _maxTeams = 2;
      _positions = ['A', 'B', 'C', 'D'];
    } else if (combined.contains('2v2')) {
      _maxTeams = 2;
      _positions = ['1', '2'];
    } else if (combined.contains('1v1')) {
      _maxTeams = 2;
      _positions = ['1'];
    } else if (combined.contains('survival') || combined.contains('br survival')) {
      _maxTeams = 20;
      _positions = ['1'];
    } else {
      if (combined.contains('squad')) {
        _maxTeams = 12;
        _positions = ['1', '2', '3', '4'];
      } else if (combined.contains('duo')) {
        _maxTeams = 24;
        _positions = ['1', '2'];
      } else {
        _maxTeams = 48;
        _positions = ['1'];
      }
    }

    _entryFee = dbl(widget.tournamentData['entry_fee']);
  }

  Future<void> _fetchUserDataAndBookings() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      final profileRes = await Supabase.instance.client
          .from('profiles')
          .select('deposit_balance, winning_balance')
          .eq('id', user.id)
          .maybeSingle();

      if (profileRes != null && mounted) {
        final dep = dbl(profileRes['deposit_balance']);
        final win = dbl(profileRes['winning_balance']);
        _walletBalance = dep + win;
      }

      final participantsRes = await Supabase.instance.client
          .from('participants')
          .select('team_no, position, slot_no')
          .eq('tournament_id', widget.tournamentId);

      if (participantsRes != null && mounted) {
        final Set<String> booked = {};
        for (var p in (participantsRes as List)) {
          final tNo = p['team_no'] ?? p['slot_no'] ?? 1;
          final pos = (p['position'] ?? '1').toString();
          booked.add('${tNo}_$pos');
        }
        setState(() {
          _bookedSlots = booked;
        });
      }
    } catch (_) {
    } finally {
      if (mounted) setState(() => _fetchingData = false);
    }
  }

  // Fix 1 & 2 & 3: Safe RPC Response, Backend Validation, Refresh on Fail
  Future<void> _processFinalJoin() async {
    if (_selectedTeamSlot == null) return;

    final ign = _ignController.text.trim();
    final ffId = _ffIdController.text.trim();

    if (ign.isEmpty) {
      snack(context, 'Please enter your In-Game Name / Username!');
      return;
    }

    final parts = _selectedTeamSlot!.split('_');
    final teamNo = int.tryParse(parts[0]) ?? 1;
    final position = parts[1];

    setState(() => _loading = true);

    try {
      final dynamic res = await Supabase.instance.client.rpc(
        'join_tournament',
        params: {
          'p_tournament_id': widget.tournamentId,
          'p_team_no': teamNo,
          'p_position': position,
          'p_ign': ign,
          'p_game_id': ffId,
        },
      );

      // Safe Response Parsing (Fix 1)
      Map<String, dynamic>? responseMap;
      if (res is List && res.isNotEmpty) {
        responseMap = res.first as Map<String, dynamic>?;
      } else if (res is Map) {
        responseMap = Map<String, dynamic>.from(res);
      }

      if (responseMap != null && responseMap['status'] == 'success') {
        if (mounted) {
          snack(context, 'SUCCESSFULLY JOINED!');
          widget.onJoined();
          Navigator.pop(context);
        }
      } else {
        final errorMsg = responseMap?['message'] ?? 'Error joining tournament';
        if (mounted) snack(context, errorMsg);
        
        // Fix 3: Refresh booked slots immediately if failed (slot taken)
        _fetchUserDataAndBookings();
        setState(() => _currentStep = 1);
      }
    } catch (e) {
      if (mounted) snack(context, 'Something went wrong. Please try again.');
      _fetchUserDataAndBookings();
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kInk),
          onPressed: () {
            if (_currentStep == 2) {
              setState(() => _currentStep = 1);
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: const Text(
          'JOINING MATCH',
          style: TextStyle(color: kInk, fontWeight: FontWeight.w900, fontSize: 16),
        ),
      ),
      body: _fetchingData
          ? const Center(child: CircularProgressIndicator(color: kIndigo))
          : Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  color: const Color(0xFF00BCD4),
                  child: const Center(
                    child: Text(
                      'SELECT MATCH POSITION',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 0.8),
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: _currentStep == 1 ? _buildStep1View() : _buildStep2View(),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildStep1View() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.02),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(color: Colors.amber.shade50, borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.account_balance_wallet_rounded, color: Colors.amber, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Your Current Balance', style: TextStyle(fontSize: 10, color: kGrey, fontWeight: FontWeight.bold)),
                      Text('₹${_walletBalance.toStringAsFixed(2)}', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: Colors.amber.shade800)),
                    ],
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('Total Payable', style: TextStyle(fontSize: 10, color: kGrey, fontWeight: FontWeight.bold)),
                  Text('₹${_entryFee.toStringAsFixed(2)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: kInk)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: const BoxDecoration(
                  color: Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                  border: Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
                ),
                child: Row(
                  children: [
                    const Expanded(flex: 2, child: Text('TEAM', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11, color: kGrey))),
                    for (var pos in _positions)
                      Expanded(
                        child: Center(
                          child: Text(pos, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11, color: kGrey)),
                        ),
                      ),
                  ],
                ),
              ),
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _maxTeams,
                separatorBuilder: (_, __) => const Divider(height: 1, color: Color(0xFFF1F5F9)),
                itemBuilder: (ctx, index) {
                  final teamNo = index + 1;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Text('Team $teamNo', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: kInk)),
                        ),
                        for (var pos in _positions) ...[
                          Builder(builder: (context) {
                            final slotKey = '${teamNo}_$pos';
                            final isBooked = _bookedSlots.contains(slotKey);
                            final isSelected = _selectedTeamSlot == slotKey;

                            return Expanded(
                              child: Center(
                                child: InkWell(
                                  onTap: isBooked
                                      ? null
                                      : () {
                                          setState(() {
                                            _selectedTeamSlot = slotKey;
                                            _selectedTeamName = 'Team $teamNo';
                                            _selectedPosName = pos;
                                          });
                                        },
                                  child: Opacity(
                                    opacity: isBooked ? 0.3 : 1.0,
                                    child: Container(
                                      width: 22,
                                      height: 22,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: isBooked
                                            ? Colors.grey.shade400
                                            : (isSelected ? const Color(0xFF00BCD4) : Colors.white),
                                        border: Border.all(
                                          color: isBooked ? Colors.grey.shade400 : const Color(0xFF00BCD4),
                                          width: 2,
                                        ),
                                      ),
                                      child: isSelected
                                          ? const Icon(Icons.check, size: 14, color: Colors.white)
                                          : null,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }),
                        ],
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          height: 48,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _selectedTeamSlot == null ? Colors.grey.shade300 : const Color(0xFFE11D48),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 0,
            ),
            onPressed: _selectedTeamSlot == null
                ? null
                : () {
                    setState(() => _currentStep = 2);
                  },
            child: Text(
              'JOIN NOW',
              style: TextStyle(
                color: _selectedTeamSlot == null ? Colors.grey.shade600 : Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 14,
                letterSpacing: 1,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStep2View() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            children: [
              _summaryRow('Your Current Balance :', '🪙 ₹${_walletBalance.toStringAsFixed(2)}', valColor: Colors.amber.shade800),
              const Divider(height: 20, color: Color(0xFFF1F5F9)),
              _summaryRow('Entry Fee Per Person :', '🪙 ₹${_entryFee.toStringAsFixed(2)}'),
              const Divider(height: 20, color: Color(0xFFF1F5F9)),
              _summaryRow('Total Payable Amount :', '🪙 ₹${_entryFee.toStringAsFixed(2)}', isBold: true, valColor: const Color(0xFF059669)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            children: [
              const Text(
                'SELECTED POSITION',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: Color(0xFF00BCD4), letterSpacing: 0.8),
              ),
              const SizedBox(height: 12),
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Team', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: kGrey)),
                  Text('Position', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: kGrey)),
                  Text('InGameName', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: kGrey)),
                ],
              ),
              const Divider(height: 16, color: Color(0xFFF1F5F9)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(_selectedTeamName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: kInk)),
                  Text(_selectedPosName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: kInk)),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: const Color(0xFF00BCD4), borderRadius: BorderRadius.circular(6)),
                    child: const Text('Add info', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('PLAYER GAME DETAILS', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: kInk)),
              const SizedBox(height: 14),
              const Text('In Game Name / Username', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: kInk)),
              const SizedBox(height: 6),
              TextField(
                controller: _ignController,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: kInk),
                decoration: InputDecoration(
                  hintText: 'Enter your exact game name',
                  hintStyle: const TextStyle(color: kGrey, fontSize: 12, fontWeight: FontWeight.normal),
                  filled: true,
                  fillColor: const Color(0xFFF8FAFC),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF00BCD4))),
                ),
              ),
              const SizedBox(height: 14),
              const Text('Free Fire ID (Optional)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: kInk)),
              const SizedBox(height: 6),
              TextField(
                controller: _ffIdController,
                keyboardType: TextInputType.number,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: kInk),
                decoration: InputDecoration(
                  hintText: 'Enter Free Fire ID',
                  hintStyle: const TextStyle(color: kGrey, fontSize: 12, fontWeight: FontWeight.normal),
                  filled: true,
                  fillColor: const Color(0xFFF8FAFC),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF00BCD4))),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 46,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFFEF4444)),
                    backgroundColor: const Color(0xFFFEF2F2),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () => setState(() => _currentStep = 1),
                  child: const Text('CANCEL', style: TextStyle(color: Color(0xFFEF4444), fontWeight: FontWeight.bold, fontSize: 13)),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: SizedBox(
                height: 46,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF10B981),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    elevation: 0,
                  ),
                  onPressed: _loading ? null : _processFinalJoin,
                  child: _loading
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Text('JOIN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        const Center(
          child: Text('Note - Please Enter Your In Game Username/Name', style: TextStyle(fontSize: 11, color: kGrey, fontWeight: FontWeight.w500)),
        ),
      ],
    );
  }

  Widget _summaryRow(String title, String amount, {bool isBold = false, Color? valColor}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: TextStyle(fontSize: 12, fontWeight: isBold ? FontWeight.bold : FontWeight.w500, color: kInk)),
        Text(amount, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: valColor ?? kInk)),
      ],
    );
  }
}
