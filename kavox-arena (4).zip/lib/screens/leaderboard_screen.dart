import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide toInt;
import '../core/helpers.dart';
import '../core/theme.dart';

final sb = Supabase.instance.client;

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  String selectedTab = "Weekly";
  bool _loading = true;
  String _metric = 'winnings';
  List<Map<String, dynamic>> _leaderboardList = [];
  
  int? _myRank;
  double _myScore = 0;
  final String _uid = sb.auth.currentUser!.id;

  DateTime? _lastFetch; // ✅ 1 min cache ke liye

  @override
  void initState() {
    super.initState();
    _fetchLeaderboard(force: true);
  }

  String get _currentPeriod {
    if (selectedTab == "Today") return 'daily';
    if (selectedTab == "Weekly") return 'weekly';
    if (selectedTab == "Monthly") return 'monthly';
    if (selectedTab == "All Time") return 'lifetime';
    return 'weekly';
  }

  String get _rankLabel {
    if (selectedTab == "Today") return 'Your today rank:';
    if (selectedTab == "Weekly") return 'Your weekly rank:';
    if (selectedTab == "Monthly") return 'Your monthly rank:';
    return 'Your all time rank:';
  }

  Future<void> _fetchLeaderboard({bool force = false}) async {
    // ✅ 1 min tak dubara call nahi hoga, agar force nahi hai
    if (!force && _lastFetch != null && DateTime.now().difference(_lastFetch!).inSeconds < 60) {
      return;
    }

    if (mounted) setState(() => _loading = true);
    try {
      final res = await Supabase.instance.client.rpc('get_leaderboard', params: {
        'p_period': _currentPeriod,
        'p_metric': _metric,
      });

      List<Map<String, dynamic>> list = [];
      if (res != null) {
        list = List<Map<String, dynamic>>.from(res);
      }

      int? myRank;
      double myScore = 0;
      int index = list.indexWhere((e) => e['user_id'] == _uid || e['id'] == _uid);
      if (index != -1) {
        myRank = index + 1;
        myScore = dbl(list[index]['total_score']);
      } else {
        try {
          final myRes = await Supabase.instance.client.rpc('get_my_rank', params: {
            'p_period': _currentPeriod,
            'p_metric': _metric,
          });
          if (myRes != null && myRes is List && myRes.isNotEmpty) {
            myRank = toInt(myRes.first['rank']);
            myScore = dbl(myRes.first['total_score']);
          } else if (myRes is Map) {
            myRank = toInt((myRes as Map)['rank']);
            myScore = dbl(myRes['total_score']);
          }
        } catch (_) {}
      }

      if (mounted) {
        setState(() {
          _leaderboardList = list;
          _myRank = myRank;
          _myScore = myScore;
          _loading = false;
          _lastFetch = DateTime.now();
        });
      }
    } catch (e) {
      if (mounted) {
        snack(context, errText(e));
        setState(() => _loading = false);
      }
    }
  }

  Widget _tab(String label) {
    bool isSelected = selectedTab == label;
    return GestureDetector(
      onTap: () {
        setState(() => selectedTab = label);
        _fetchLeaderboard(force: true); // ✅ tab change pe force
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF101828) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isSelected ? const Color(0xFF101828) : const Color(0xFFE4E7EC)),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : const Color(0xFF667085),
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Widget _rankCircle(int rank) {
    if (rank == 1) {
      return Container(width: 32, height: 32, decoration: const BoxDecoration(color: Color(0xFFFFC72C), shape: BoxShape.circle), child: const Center(child: Text("1", style: TextStyle(fontWeight: FontWeight.w900, color: Colors.black, fontSize: 12))));
    } else if (rank == 2) {
      return Container(width: 32, height: 32, decoration: const BoxDecoration(color: Color(0xFFD0D5DD), shape: BoxShape.circle), child: const Center(child: Text("2", style: TextStyle(fontWeight: FontWeight.w900, color: Colors.black, fontSize: 12))));
    } else if (rank == 3) {
      return Container(width: 32, height: 32, decoration: const BoxDecoration(color: Color(0xFFF79009), shape: BoxShape.circle), child: const Center(child: Text("3", style: TextStyle(fontWeight: FontWeight.w900, color: Colors.black, fontSize: 12))));
    } else {
      return Container(width: 32, height: 32, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xFF101828), width: 1.2)), child: Center(child: Text("$rank", style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF101828), fontSize: 12))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const Text('KAVOX ARENA', style: TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 0.5, fontStyle: FontStyle.italic)),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Color(0xFF101828)),
            onSelected: (val) {
              setState(() => _metric = val);
              _fetchLeaderboard(force: true);
            },
            itemBuilder: (context) => [
              PopupMenuItem(value: 'winnings', child: Text('Top Earners', style: TextStyle(fontWeight: _metric == 'winnings' ? FontWeight.bold : FontWeight.normal))),
              PopupMenuItem(value: 'kills', child: Text('Top Killers', style: TextStyle(fontWeight: _metric == 'kills' ? FontWeight.bold : FontWeight.normal))),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 8),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Row(children: [_tab("Today"), const SizedBox(width: 8), _tab("Weekly"), const SizedBox(width: 8), _tab("Monthly"), const SizedBox(width: 8), _tab("All Time")])),
          const SizedBox(height: 14),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 14),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(color: const Color(0xFFF9FAFB), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE4E7EC))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_rankLabel, style: const TextStyle(color: Color(0xFF667085), fontSize: 13, fontWeight: FontWeight.w500)),
                Text(_myRank == null ? "#--" : "#$_myRank", style: const TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w800, fontSize: 13)),
                Text(_metric == 'winnings' ? "₹${_myScore.toStringAsFixed(0)}.00" : "${_myScore.toInt()}", style: const TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w600, fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10), child: Row(children: [SizedBox(width: 40, child: Text("Rank", style: TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w700, fontSize: 12))), Expanded(child: Text("Player", style: TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w700, fontSize: 12))), SizedBox(width: 50, child: Text("Wins", style: TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w700, fontSize: 12), textAlign: TextAlign.center)), SizedBox(width: 85, child: Text("Rewards", style: TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w700, fontSize: 12), textAlign: TextAlign.right))])),
          const Divider(height: 1, color: Color(0xFFE4E7EC)),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: Color(0xFF101828)))
                : _leaderboardList.isEmpty
                    ? ListView(children: const [SizedBox(height: 200), Center(child: Text('No leaderboard records found for this period.', style: TextStyle(color: Color(0xFF98A2B3), fontWeight: FontWeight.w600, fontSize: 13)) )])
                    : RefreshIndicator(
                        onRefresh: () => _fetchLeaderboard(force: true),
                        child: ListView.separated(
                          itemCount: _leaderboardList.length,
                          separatorBuilder: (_, __) => const Divider(height: 1, color: Color(0xFFF2F4F7)),
                          itemBuilder: (ctx, i) {
                            final item = _leaderboardList[i];
                            final ign = item['ign'] ?? item['username'] ?? 'Player';
                            final score = dbl(item['total_score']);
                            final wins = item['total_wins'] ?? item['wins'] ?? 0;
                            final isWinnings = _metric == 'winnings';
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              child: Row(
                                children: [
                                  _rankCircle(i + 1),
                                  const SizedBox(width: 12),
                                  Expanded(child: Text(ign, style: const TextStyle(color: Color(0xFF101828), fontSize: 14, fontWeight: FontWeight.w600), overflow: TextOverflow.ellipsis)),
                                  Container(width: 48, padding: const EdgeInsets.symmetric(vertical: 4), decoration: BoxDecoration(border: Border.all(color: const Color(0xFF101828)), borderRadius: BorderRadius.circular(12)), child: Center(child: Text("$wins", style: const TextStyle(color: Color(0xFF101828), fontSize: 11, fontWeight: FontWeight.w700)))),
                                  const SizedBox(width: 10),
                                  SizedBox(width: 80, child: Text(isWinnings ? "₹${score.toStringAsFixed(0)}.00" : "${score.toInt()}", style: const TextStyle(color: Color(0xFF101828), fontWeight: FontWeight.w800, fontSize: 13), textAlign: TextAlign.right)),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}