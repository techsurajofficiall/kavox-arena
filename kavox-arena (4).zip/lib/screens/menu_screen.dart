import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide toInt;
import '../core/helpers.dart';
import '../core/theme.dart';
import '../core/widgets.dart';

import 'about_us_screen.dart';
import 'contact_screen.dart';
import 'faq_screen.dart';
import 'leaderboard_screen.dart';
import 'notifications_screen.dart';
import 'profile_screen.dart';
import 'statistics_screen.dart';
import 'terms_privacy_screen.dart';
import 'wallet_screen.dart';

final sb = Supabase.instance.client;

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final String _uid = sb.auth.currentUser!.id;
  late final Stream<List<Json>> _me = sb.from('profiles').stream(primaryKey: ['id']).eq('id', _uid);

  int _matches = 0;
  int _kills = 0;
  double _earning = 0;

  // ✅ Supabase se logo load
  String _getStorageUrl(String fileName) {
    return Supabase.instance.client.storage.from('Kavox-arena').getPublicUrl(fileName);
    // agar bucket small letter me hai to 'kavox-arena' kar de
  }

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final res = await sb.rpc('get_my_stats');
      if (res is List && res.isNotEmpty && mounted) {
        final r = res.first as Map;
        setState(() {
          _matches = toInt(r['matches_played']);
          _kills = toInt(r['total_kills']);
          _earning = dbl(r['total_earning']);
        });
      }
    } catch (_) {}
  }

  void _open(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  Future<void> _logout() async {
    try {
      await sb.auth.signOut();
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Widget _stat(String value, String label) {
    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Color(0xFF101828))),
          const SizedBox(height: 4),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Color(0xFF667085), height: 1.2)),
        ],
      ),
    );
  }

  Widget _tile(IconData icon, Color iconColor, Color iconBg, String title, VoidCallback onTap, {bool danger = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: danger ? const Color(0xFFFECACA) : const Color(0xFFE4E7EC)),
          ),
          child: Row(
            children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: iconColor, size: 22)),
              const SizedBox(width: 12),
              Expanded(child: Text(title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: danger ? const Color(0xFFDC2626) : const Color(0xFF101828)))),
              Icon(Icons.chevron_right_rounded, color: danger ? const Color(0xFFDC2626) : const Color(0xFF98A2B3), size: 20),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F4F7),
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        elevation: 0,
        title: const Text('MENU', style: TextStyle(letterSpacing: 0.5, fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF101828))),
        actions: [
          StreamBuilder<List<Json>>(stream: _me, builder: (context, s) {
            final p = (s.data?.isNotEmpty ?? false) ? s.data!.first : null;
            final total = p == null ? 0.0 : dbl(p['deposit_balance']) + dbl(p['winning_balance']);
            return Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: GestureDetector(onTap: () => _open(const WalletScreen()), child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF6941C6), borderRadius: BorderRadius.circular(20)), child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.account_balance_wallet_outlined, color: Colors.white, size: 14), const SizedBox(width: 6), Text('₹${money(total)}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12))])))));
          }),
        ],
      ),
      body: StreamBuilder<List<Json>>(stream: _me, builder: (context, s) {
        final p = (s.data?.isNotEmpty ?? false) ? s.data!.first : {'username': 'Gamer'};
        final username = '${p['username'] ?? 'Gamer'}';
        return ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.fromLTRB(14, 12, 14, 20), children: [
          // ✅ LOGO - AB SUPABASE SE - ICON NAHI AAYEGA
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: CachedNetworkImage(
                imageUrl: _getStorageUrl('kavox_icon.webp'),
                width: 60,
                height: 60,
                fit: BoxFit.cover,
                placeholder: (c, u) => Container(width: 60, height: 60, color: const Color(0xFFE4E7EC)),
                errorWidget: (c, u, e) => Container(width: 60, height: 60, color: const Color(0xFF6941C6), child: const Icon(Icons.person, color: Colors.white, size: 30)),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(child: Text(username.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF101828)))),
          const SizedBox(height: 16),
          Container(padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE4E7EC))), child: Row(children: [_stat('$_matches', 'MATCHES\nPLAYED'), Container(width: 1, height: 36, color: const Color(0xFFE4E7EC)), _stat('$_kills', 'TOTAL\nKILLS'), Container(width: 1, height: 36, color: const Color(0xFFE4E7EC)), _stat('₹${money(_earning)}', 'TOTAL\nEARNING')])),
          const SizedBox(height: 16),
          _tile(Icons.person, const Color(0xFF2E5AAC), const Color(0xFFE0EAFF), 'My Profile', () => _open(const ProfileScreen())),
          _tile(Icons.account_balance_wallet, const Color(0xFFB45309), const Color(0xFFFEF3C7), 'My Wallet', () => _open(const WalletScreen())),
          _tile(Icons.bar_chart_rounded, const Color(0xFF6941C6), const Color(0xFFF4EBFF), 'My Statistics', () => _open(const StatisticsScreen())),
          _tile(Icons.emoji_events, const Color(0xFFA16207), const Color(0xFFFEF9C7), 'Top Players', () => _open(const LeaderboardScreen())),
          _tile(Icons.notifications, const Color(0xFF026AA2), const Color(0xFFE0F2FE), 'Notifications', () => _open(const NotificationsScreen())),
          _tile(Icons.support_agent, const Color(0xFF067647), const Color(0xFFDCFAE6), 'Contact Us', () => ContactScreen.showContactPopup(context)),
          _tile(Icons.help, const Color(0xFF0E7090), const Color(0xFFCFF9FE), 'FAQ', () => _open(const FaqScreen())),
          _tile(Icons.info, const Color(0xFF7A5AF8), const Color(0xFFF4EBFF), 'About Us', () => _open(const AboutUsScreen())),
          _tile(Icons.lock, const Color(0xFFC01048), const Color(0xFFFEE4E2), 'Privacy Policy', () => _open(const PrivacyScreen())),
          _tile(Icons.shield, const Color(0xFF067647), const Color(0xFFDCFAE6), 'Terms & Conditions', () => _open(const TermsScreen())),
          _tile(Icons.power_settings_new, const Color(0xFFD92D20), const Color(0xFFFEE4E2), 'Logout', _logout, danger: true),
          const SizedBox(height: 16),
          const Center(child: Text('KAVOX ARENA v1.0.0', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Color(0xFF6941C6)))),
          const SizedBox(height: 4),
          const Center(child: Text('All Rights Reserved © 2026', style: TextStyle(fontSize: 10, color: Color(0xFF98A2B3)))),
        ]);
      }),
    );
  }
}