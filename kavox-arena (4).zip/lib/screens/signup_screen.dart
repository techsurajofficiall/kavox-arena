import 'package:flutter/material.dart';
import '../core/helpers.dart';
import 'terms_privacy_screen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  final _passwordController = TextEditingController();
  final _referralController = TextEditingController();

  // --- NAYA: 4 Box PIN ke liye ---
  final _pinControllers = List.generate(4, (_) => TextEditingController());
  final _pinFocusNodes = List.generate(4, (_) => FocusNode());

  bool _isPasswordVisible = false;
  bool _isLoading = false;
  bool _agreedToTerms = true;

  String get _securityPin => _pinControllers.map((c) => c.text).join();

  bool _isWeakPin(String pin) {
    if (pin.length != 4) return true;
    // 0000, 1111, 2222 etc block
    if (pin.split('').toSet().length == 1) return true;
    // sirf 1234 block
    if (pin == '1234') return true;
    return false;
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    _mobileController.dispose();
    _passwordController.dispose();
    _referralController.dispose();
    for (var c in _pinControllers) { c.dispose(); }
    for (var f in _pinFocusNodes) { f.dispose(); }
    super.dispose();
  }

  void _openTermsScreen() {
    Navigator.push(context, MaterialPageRoute(builder: (context) => const TermsScreen()));
  }

  void _openPrivacyScreen() {
    Navigator.push(context, MaterialPageRoute(builder: (context) => const PrivacyScreen()));
  }

  Future<void> _handleSignup() async {
    final username = _usernameController.text.trim();
    final email = _emailController.text.trim();
    final mobile = _mobileController.text.trim();
    final password = _passwordController.text.trim();
    final referralCode = _referralController.text.trim().toUpperCase();
    final securityPin = _securityPin;

    if (username.isEmpty || email.isEmpty || mobile.isEmpty || password.isEmpty) {
      snack(context, 'Please fill all required fields');
      return;
    }
    if (username.length < 3) {
      snack(context, 'Username must be at least 3 characters');
      return;
    }
    if (!email.contains('@')) {
      snack(context, 'Enter a valid email address');
      return;
    }
    if (!RegExp(r'^[0-9]{10}$').hasMatch(mobile)) {
      snack(context, 'Enter a valid 10 digit mobile number');
      return;
    }
    if (password.length < 6) {
      snack(context, 'Password must be at least 6 characters');
      return;
    }
    if (!RegExp(r'^[0-9]{4}$').hasMatch(securityPin)) {
      snack(context, 'Enter 4-digit Security PIN');
      return;
    }
    if (_isWeakPin(securityPin)) {
      snack(context, 'Avoid 1234 or same digits like 1111. Choose another PIN');
      return;
    }
    if (!_agreedToTerms) {
      snack(context, 'Please accept Terms & Conditions');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final ok = await sb.rpc('username_available', params: {'p_username': username});
      if (ok != true) throw 'This username is already taken';

      final response = await sb.auth.signUp(
        email: email,
        password: password,
        data: {'username': username, 'phone': mobile},
      );

      final userId = response.user?.id ?? response.session?.user.id;

      if (userId != null) {
        await sb.from('profiles').update({'security_pin': securityPin}).eq('id', userId);

        if (referralCode.isNotEmpty) {
          try {
            final refUser = await sb.from('profiles').select('id').eq('referral_code', referralCode).maybeSingle();
            if (refUser != null && refUser['id'] != userId) {
              await sb.from('profiles').update({'referred_by': refUser['id']}).eq('id', userId);
            }
          } catch (_) {}
        }
      }

      if (!mounted) return;

      if (response.session == null) {
        snack(context, 'Check your email to confirm your account, then login.');
        Navigator.pop(context);
      } else {
        snack(context, 'Registration Successful! Welcome to Arena.');
        Navigator.of(context).popUntil((r) => r.isFirst);
      }
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Widget _buildInputContainer({required Widget child}) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Color(0xFF0F172A)), onPressed: () => Navigator.pop(context)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Create Account', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
              const SizedBox(height: 6),
              const Text('Join KAVOX ARENA & start competing in daily tournaments.', style: TextStyle(fontSize: 13, color: Color(0xFF64748B))),
              const SizedBox(height: 25),

              const Text('USERNAME', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
              const SizedBox(height: 6),
              _buildInputContainer(child: TextField(controller: _usernameController, decoration: const InputDecoration(hintText: 'Enter gamer username', hintStyle: TextStyle(fontSize: 13, color: Color(0xFF94A3B8)), prefixIcon: Icon(Icons.person_outline, color: Color(0xFF94A3B8)), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 14)))),

              const SizedBox(height: 16),
              const Text('EMAIL ADDRESS', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
              const SizedBox(height: 6),
              _buildInputContainer(child: TextField(controller: _emailController, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'Enter email address', hintStyle: TextStyle(fontSize: 13, color: Color(0xFF94A3B8)), prefixIcon: Icon(Icons.email_outlined, color: Color(0xFF94A3B8)), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 14)))),

              const SizedBox(height: 16),
              const Text('MOBILE NUMBER', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
              const SizedBox(height: 6),
              _buildInputContainer(child: TextField(controller: _mobileController, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: 'Enter mobile number', hintStyle: TextStyle(fontSize: 13, color: Color(0xFF94A3B8)), prefixIcon: Icon(Icons.phone_android_outlined, color: Color(0xFF94A3B8)), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 14)))),

              const SizedBox(height: 16),
              const Text('PASSWORD', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
              const SizedBox(height: 6),
              _buildInputContainer(child: TextField(controller: _passwordController, obscureText: !_isPasswordVisible, decoration: InputDecoration(hintText: '••••••••', hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF94A3B8)), prefixIcon: const Icon(Icons.lock_outline, color: Color(0xFF94A3B8)), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 14), suffixIcon: TextButton(onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible), child: Text(_isPasswordVisible ? 'Hide' : 'Show', style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12)))))),

              const SizedBox(height: 16),
              const Text('REFERRAL CODE (Optional)', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
              const SizedBox(height: 6),
              _buildInputContainer(child: TextField(controller: _referralController, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(hintText: 'Enter referral code', hintStyle: TextStyle(fontSize: 13, color: Color(0xFF94A3B8)), prefixIcon: Icon(Icons.card_giftcard_outlined, color: Color(0xFF94A3B8)), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 14)))),

              const SizedBox(height: 16),
              const Text('SECURITY PIN (4-DIGIT)', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(4, (index) {
                  return Container(
                    width: 68,
                    height: 58,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _pinControllers[index].text.isNotEmpty ? const Color(0xFF6366F1) : const Color(0xFFE2E8F0), width: 1.5),
                    ),
                    child: TextField(
                      controller: _pinControllers[index],
                      focusNode: _pinFocusNodes[index],
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      maxLength: 1,
                      obscureText: true,
                      obscuringCharacter: '●',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF0F172A)),
                      decoration: const InputDecoration(counterText: '', border: InputBorder.none),
                      onChanged: (val) {
                        if (val.isNotEmpty && index < 3) {
                          _pinFocusNodes[index + 1].requestFocus();
                        }
                        if (val.isEmpty && index > 0) {
                          _pinFocusNodes[index - 1].requestFocus();
                        }
                        setState(() {});
                      },
                    ),
                  );
                }),
              ),
              const SizedBox(height: 6),
              const Text('This PIN is required for withdrawal & account delete. 1111, 0000, 1234 not allowed.', style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),

              const SizedBox(height: 16),
              Row(
                children: [
                  Checkbox(value: _agreedToTerms, activeColor: const Color(0xFF6366F1), onChanged: (val) => setState(() => _agreedToTerms = val ?? true)),
                  Expanded(child: Wrap(children: [const Text('I agree to the ', style: TextStyle(fontSize: 12, color: Color(0xFF64748B))), GestureDetector(onTap: _openTermsScreen, child: const Text('Terms', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF6366F1)))), const Text(' & ', style: TextStyle(fontSize: 12, color: Color(0xFF64748B))), GestureDetector(onTap: _openPrivacyScreen, child: const Text('Privacy Policy', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF6366F1))))])),
                ],
              ),
              const SizedBox(height: 25),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _handleSignup,
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6366F1), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), elevation: 2),
                  child: _isLoading ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)) : const Text('CREATE ACCOUNT', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}