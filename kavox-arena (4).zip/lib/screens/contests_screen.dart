import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';
import 'tournament_detail_screen.dart';
import 'wallet_screen.dart';

class ContestsScreen extends StatefulWidget {
  final String category;
  const ContestsScreen({super.key, this.category = 'BR SURVIVAL'});

  @override
  State<ContestsScreen> createState() => _ContestsScreenState();
}

class _ContestsScreenState extends State<ContestsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _loading = true;
  List<dynamic> _tournaments = [];
  double _walletBalance = 0.0;
  
  // Realtime Supabase Channels
  RealtimeChannel? _tournamentsChannel;
  RealtimeChannel? _participantsChannel;

  @override
  void initState() {
    super.initState();
    // Tab Order: Ongoing (0), Upcoming (1), Completed (2)
    _tabController = TabController(length: 3, vsync: this, initialIndex: 1);
    _fetchContestsData();
    _setupRealtimeSubscriptions();
  }

  @override
  void dispose() {
    // Clean up realtime listeners when screen closed
    if (_tournamentsChannel != null) Supabase.instance.client.removeChannel(_tournamentsChannel!);
    if (_participantsChannel != null) Supabase.instance.client.removeChannel(_participantsChannel!);
    _tabController.dispose();
    super.dispose();
  }

  // Live Auto Sync: Bina Reload Ke Participant Count & Match Update Karega
  void _setupRealtimeSubscriptions() {
    final client = Supabase.instance.client;

    // Listen to Tournaments Changes
    _tournamentsChannel = client
        .channel('public:tournaments_contests')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'tournaments',
          callback: (_) => _fetchContestsData(isSilent: true),
        )
        .subscribe();

    // Listen to Participants Table (Jab Bhi Koi User Join Karega Instantly Auto Refresh Hoga)
    _participantsChannel = client
        .channel('public:participants_contests')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'participants',
          callback: (_) => _fetchContestsData(isSilent: true),
        )
        .subscribe();
  }

  Future<void> _fetchContestsData({bool isSilent = false}) async {
    final user = Supabase.instance.client.auth.currentUser;
    try {
      if (user != null) {
        final profileRes = await Supabase.instance.client
            .from('profiles')
            .select('deposit_balance, winning_balance')
            .eq('id', user.id)
            .maybeSingle();

        if (profileRes != null && mounted) {
          final dep = dbl(profileRes['deposit_balance']);
          final win = dbl(profileRes['winning_balance']);
          setState(() {
            _walletBalance = dep + win;
          });
        }
      }

      final res = await Supabase.instance.client
          .from('tournaments')
          .select('*, participants(count)')
          .eq('category', widget.category)
          .order('start_time', ascending: true);

      if (res != null && mounted) {
        setState(() {
          _tournaments = res;
          if (!isSilent) _loading = false;
        });
      }
    } catch (_) {
    } finally {
      if (mounted && !isSilent) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ongoing = _tournaments.where((m) => ['live', 'ongoing'].contains((m['status'] ?? '').toString().toLowerCase())).toList();
    final upcoming = _tournaments.where((m) => (m['status'] ?? 'upcoming').toString().toLowerCase() == 'upcoming').toList();
    final completed = _tournaments.where((m) => ['completed', 'finished', 'resulted'].contains((m['status'] ?? '').toString().toLowerCase())).toList();

    return Scaffold(
      backgroundColor: Colors.white, // Pure White Background
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kInk),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          '${widget.category.toUpperCase()} Contests',
          style: const TextStyle(color: kInk, fontWeight: FontWeight.bold, fontSize: 17),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0, top: 8, bottom: 8),
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const WalletScreen()),
                ).then((_) => _fetchContestsData());
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kIndigo, Color(0xFF8B5CF6)]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.account_balance_wallet, color: Colors.white, size: 16),
                    const SizedBox(width: 6),
                    Text(
                      '₹${_walletBalance.toStringAsFixed(0)}',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: kIndigo,
          unselectedLabelColor: kGrey,
          indicatorColor: kIndigo,
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
          tabs: const [
            Tab(text: 'Ongoing'),
            Tab(text: 'Upcoming'),
            Tab(text: 'Completed'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kIndigo))
          : RefreshIndicator(
              onRefresh: () => _fetchContestsData(),
              color: kIndigo,
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildMatchList(ongoing, 'No Ongoing Matches Currently'),
                  _buildMatchList(upcoming, 'No Upcoming Tournaments Right Now'),
                  _buildMatchList(completed, 'No Completed Matches Yet'),
                ],
              ),
            ),
    );
  }

  Widget _buildMatchList(List<dynamic> list, String emptyMessage) {
    if (list.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.sports_esports, size: 60, color: kGrey),
            const SizedBox(height: 12),
            Text(emptyMessage, style: const TextStyle(color: kGrey, fontWeight: FontWeight.bold)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(14),
      itemCount: list.length,
      itemBuilder: (ctx, i) {
        final item = list[i];
        final id = item['id'];
        final title = item['title'] ?? 'Free Fire Match';
        final bannerUrl = item['image'] ?? item['banner'] ?? '';
        final entryFee = dbl(item['entry_fee']);
        final prizePool = dbl(item['prize_pool']);
        final perKill = dbl(item['per_kill']);
        final matchType = item['match_type'] ?? 'Solo';
        final mapName = item['map'] ?? 'Bermuda';
        final status = (item['status'] ?? 'upcoming').toString().toLowerCase();
        
        final startTimeRaw = item['start_time'];
        final startTime = startTimeRaw != null ? formatDt(startTimeRaw) : 'TBA';
        
        final totalSlots = item['max_slots'] ?? 48;

        // Auto Extract Live Count
        int participantsCount = 0;
        final participantsList = item['participants'];
        if (participantsList is List && participantsList.isNotEmpty) {
          final first = participantsList.first;
          if (first is Map && first['count'] != null) {
            participantsCount = int.tryParse(first['count'].toString()) ?? 0;
          }
        }

        final spotsLeft = totalSlots - participantsCount;
        final progress = totalSlots > 0 ? (participantsCount / totalSlots) : 0.0;
        final isCompleted = status == 'completed' || status == 'finished' || status == 'resulted';

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Banner Image Section
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                child: bannerUrl.isNotEmpty
                    ? Image.network(
                        bannerUrl,
                        height: 150,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => _buildDefaultBanner(),
                      )
                    : _buildDefaultBanner(),
              ),
              
              Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: kInk),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Time : $startTime',
                      style: const TextStyle(fontSize: 11, color: kGrey, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 12),
                    
                    // Stats Row 1
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _infoChip('PRIZE POOL', '₹${prizePool.toStringAsFixed(0)}', Icons.emoji_events_rounded, Colors.amber.shade700),
                        _infoChip('PER KILL', '₹${perKill.toStringAsFixed(0)}', Icons.gps_fixed_rounded, Colors.blue.shade600),
                        _infoChip('ENTRY FEE', entryFee == 0 ? 'FREE' : '₹${entryFee.toStringAsFixed(0)}', Icons.payments_rounded, kIndigo),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const Divider(height: 1, color: Color(0xFFF1F5F9)),
                    const SizedBox(height: 10),

                    // Stats Row 2
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _infoChip('TYPE', matchType, Icons.person_rounded, Colors.purple.shade600),
                        _infoChip('ENTRY PER PLAYER', entryFee == 0 ? 'FREE' : '₹${entryFee.toStringAsFixed(0)}', Icons.group_rounded, Colors.orange.shade600),
                        _infoChip('MAP', mapName, Icons.map_rounded, Colors.teal.shade600),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Spots Progress Bar (Instant Animated)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: progress.clamp(0.0, 1.0),
                        backgroundColor: const Color(0xFFF1F5F9),
                        color: spotsLeft <= 5 ? kRed : kIndigo,
                        minHeight: 6,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          isCompleted ? 'MATCH COMPLETED' : 'Only $spotsLeft Spot Left',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: isCompleted ? kGrey : (spotsLeft <= 5 ? kRed : const Color(0xFF059669)),
                          ),
                        ),
                        // Real-time live count update text
                        Text('$participantsCount/$totalSlots', style: const TextStyle(fontSize: 11, color: kGrey, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Join Button
                    SizedBox(
                      width: double.infinity,
                      height: 42,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: (spotsLeft <= 0 || isCompleted) ? kGrey : kIndigo,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          elevation: 0,
                        ),
                        onPressed: (spotsLeft <= 0 || isCompleted)
                            ? null
                            : () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => TournamentDetailScreen(tournamentId: id),
                                  ),
                                ).then((_) => _fetchContestsData());
                              },
                        child: Text(
                          isCompleted ? 'RESULTED' : (spotsLeft <= 0 ? 'MATCH FULL' : 'Join'),
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDefaultBanner() {
    return Container(
      height: 150,
      width: double.infinity,
      color: const Color(0xFFE2E8F0),
      child: const Center(
        child: Icon(Icons.sports_esports_rounded, color: Color(0xFF64748B), size: 42),
      ),
    );
  }

  Widget _infoChip(String label, String value, IconData icon, Color iconColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: kGrey)),
        const SizedBox(height: 2),
        Row(
          children: [
            Icon(icon, size: 12, color: iconColor),
            const SizedBox(width: 4),
            Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kInk)),
          ],
        ),
      ],
    );
  }
}
