import 'package:flutter/material.dart';
import '../core/helpers.dart';

class ForgetPasswordScreen extends StatefulWidget {
  const ForgetPasswordScreen({super.key});
  @override
  State<ForgetPasswordScreen> createState() => _ForgetPasswordScreenState();
}

class _ForgetPasswordScreenState extends State<ForgetPasswordScreen> {
  final _loginController = TextEditingController();
  final _emailController = TextEditingController();
  final _newPassController = TextEditingController();
  final _confirmPassController = TextEditingController();
  final _pinControllers = List.generate(4, (_) => TextEditingController());
  final _pinFocusNodes = List.generate(4, (_) => FocusNode());

  bool _isLoading = false;
  String? _loginError;
  String? _emailError;
  String? _pinError;
  String? _passError;

  String get _securityPin => _pinControllers.map((c) => c.text).join();

  void _clearErrors() {
    setState(() {
      _loginError = null;
      _emailError = null;
      _pinError = null;
      _passError = null;
    });
  }

  // CENTRE ME PREMIUM ERROR POPUP
  void _showCenterError(String message) {
    // Keyboard band karo taaki centre clear dikhe
    FocusScope.of(context).unfocus();
    
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.45),
      builder: (ctx) => Center(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 24),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 25, offset: const Offset(0, 10))],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 52, height: 52,
                decoration: BoxDecoration(color: const Color(0xFFFEF2F2), borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.close_rounded, color: Color(0xFFEF4444), size: 28),
              ),
              const SizedBox(height: 14),
              const Text('Reset Failed', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13.5, color: Color(0xFF64748B), height: 1.5)),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity, height: 46,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6366F1), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0),
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('TRY AGAIN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 0.5)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleReset() async {
    _clearErrors();
    final login = _loginController.text.trim();
    final email = _emailController.text.trim();
    final newPass = _newPassController.text.trim();
    final confirmPass = _confirmPassController.text.trim();
    final pin = _securityPin;

    bool hasError = false;
    if (login.isEmpty) { setState(() => _loginError = 'required'); hasError = true; }
    if (email.isEmpty) { setState(() => _emailError = 'required'); hasError = true; }
    else if (!email.contains('@')) { setState(() => _emailError = 'invalid'); hasError = true; }
    if (pin.length != 4) { setState(() => _pinError = 'required'); hasError = true; }
    if (newPass.isEmpty) { setState(() => _passError = 'required'); hasError = true; }
    else if (newPass.length < 6) { setState(() => _passError = 'short'); hasError = true; }
    else if (newPass != confirmPass) { setState(() => _passError = 'mismatch'); hasError = true; }

    if (hasError) {
      // Centre me ek hi error dikhao, neeche nahi
      if (_loginError != null) { _showCenterError('Please enter your Username / Mobile'); return; }
      if (_emailError != null) { _showCenterError('Please enter a valid registered Email'); return; }
      if (_pinError != null) { _showCenterError('Please enter 4-digit Security Code'); return; }
      if (_passError == 'short') { _showCenterError('Password must be at least 6 characters'); return; }
      if (_passError == 'mismatch') { _showCenterError('New password and confirm password do not match'); return; }
      _showCenterError('Please fill all fields properly');
      return;
    }

    setState(() => _isLoading = true);
    try {
      final res = await sb.rpc('reset_password_with_pin', params: {
        'p_login': login,
        'p_email': email,
        'p_pin': pin,
        'p_new_password': newPass,
      });
      
      if (res == 'SUCCESS') {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password reset successful! Please login'), backgroundColor: Color(0xFF10B981)));
          Navigator.pop(context);
        }
      } else {
        final msg = res.toString();
        if (msg.contains('Details do not match')) {
          setState(() { _loginError = 'e'; _emailError = 'e'; });
          _showCenterError('Details do not match our records!\nUsername/Mobile and Email must belong to same account.');
        } else if (msg.contains('Security Code') || msg.contains('Invalid')) {
          setState(() => _pinError = 'e');
          _showCenterError('Invalid Security Code!\nPlease check your 4-digit PIN.');
        } else {
          setState(() => _passError = 'e');
          _showCenterError(msg);
        }
      }
    } catch (e) {
      _showCenterError(errText(e));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(title: const Text('Reset Password', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), backgroundColor: const Color(0xFFF8F9FE), elevation: 0, centerTitle: true),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _label('USERNAME / MOBILE'),
            _field(_loginController, 'Enter username or mobile', hasError: _loginError != null),
            const SizedBox(height: 16),
            
            _label('REGISTERED EMAIL'),
            _field(_emailController, 'Enter registered email', hasError: _emailError != null),
            const SizedBox(height: 16),

            _label('SECURITY CODE'),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(4, (index) {
                return Container(
                  width: 68, height: 58,
                  decoration: BoxDecoration(
                    color: Colors.white, 
                    borderRadius: BorderRadius.circular(12), 
                    border: Border.all(color: _pinError != null ? const Color(0xFFEF4444) : const Color(0xFFE2E8F0), width: _pinError != null ? 1.8 : 1),
                    boxShadow: _pinError != null ? [BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.15), blurRadius: 8)] : [],
                  ),
                  child: TextField(
                    controller: _pinControllers[index],
                    focusNode: _pinFocusNodes[index],
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    maxLength: 1,
                    obscureText: true,
                    obscuringCharacter: '●',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    decoration: const InputDecoration(counterText: '', border: InputBorder.none),
                    onChanged: (val) {
                      if (val.isNotEmpty && index < 3) _pinFocusNodes[index + 1].requestFocus();
                      if (val.isEmpty && index > 0) _pinFocusNodes[index - 1].requestFocus();
                      if (_pinError != null) setState(() => _pinError = null);
                    },
                  ),
                );
              }),
            ),
            const SizedBox(height: 20),

            _label('NEW PASSWORD'),
            _field(_newPassController, 'Enter new password', isPass: true, hasError: _passError != null),
            const SizedBox(height: 16),
            _label('CONFIRM NEW PASSWORD'),
            _field(_confirmPassController, 'Confirm new password', isPass: true, hasError: _passError != null),
            
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity, height: 52,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _handleReset,
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6366F1), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), elevation: 2),
                child: _isLoading ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)) : const Text('RESET PASSWORD', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _label(String t) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(t, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B), letterSpacing: 0.5)));
  
  Widget _field(TextEditingController c, String hint, {bool isPass = false, bool hasError = false}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white, 
        borderRadius: BorderRadius.circular(14), 
        border: Border.all(color: hasError ? const Color(0xFFEF4444) : const Color(0xFFE2E8F0), width: hasError ? 1.8 : 1),
        boxShadow: hasError ? [BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.15), blurRadius: 10)] : [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10)],
      ),
      child: TextField(
        controller: c,
        obscureText: isPass,
        onChanged: (_) { if (hasError) _clearErrors(); },
        decoration: InputDecoration(hintText: hint, hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF94A3B8)), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
      ),
    );
  }
}