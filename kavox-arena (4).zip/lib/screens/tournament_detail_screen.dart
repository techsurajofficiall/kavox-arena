import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';
import 'join_slot_screen.dart';
import 'view_joinings_screen.dart';

class TournamentDetailScreen extends StatefulWidget {
  final String tournamentId;
  const TournamentDetailScreen({super.key, required this.tournamentId});

  @override
  State<TournamentDetailScreen> createState() => _TournamentDetailScreenState();
}

class _TournamentDetailScreenState extends State<TournamentDetailScreen> {
  bool _loading = true;
  Map<String, dynamic>? _match;
  bool _joined = false;
  Timer? _timer;
  Duration _timeLeft = Duration.zero;

  @override
  void initState() {
    super.initState();
    _fetchDetails();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _fetchDetails() async {
    final user = Supabase.instance.client.auth.currentUser;
    try {
      final res = await Supabase.instance.client
          .from('tournaments')
          .select('*, participants(*)')
          .eq('id', widget.tournamentId)
          .maybeSingle();

      if (res != null && mounted) {
        setState(() {
          _match = res;
          if (user != null) {
            final parts = res['participants'] as List? ?? [];
            _joined = parts.any((p) => p['user_id'] == user.id);
          }
        });
        _startTimer();
      }
    } catch (_) {} finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _startTimer() {
    if (_match == null || _match!['start_time'] == null) return;
    final startTime = DateTime.tryParse(_match!['start_time'].toString());
    if (startTime == null) return;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      final diff = startTime.difference(DateTime.now());
      if (diff.isNegative) {
        _timer?.cancel();
        setState(() => _timeLeft = Duration.zero);
      } else {
        setState(() => _timeLeft = diff);
      }
    });
  }

  String _formatDuration(Duration d) {
    if (d == Duration.zero) return 'MATCH STARTED';
    return '${d.inDays}d ${d.inHours % 24}h ${d.inMinutes % 60}m ${d.inSeconds % 60}s';
  }

  void _openSlotSelectionScreen() {
    if (_match == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => JoinSlotScreen(
          tournamentId: widget.tournamentId,
          tournamentData: _match!,
          onJoined: () => _fetchDetails(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _match == null) {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(backgroundColor: Colors.white, elevation: 0, leading: const BackButton(color: kInk)),
        body: const Center(child: CircularProgressIndicator(color: kIndigo)),
      );
    }

    final title = _match!['title'] ?? 'Contest Details';
    final bannerUrl = _match!['image'] ?? _match!['banner'] ?? '';
    final entryFee = dbl(_match!['entry_fee']);
    final mapName = _match!['map'] ?? 'Bermuda';
    final gameMode = _match!['mode'] ?? _match!['team_type'] ?? 'Solo';
    final status = (_match!['status'] ?? 'upcoming').toString().toLowerCase();
    final isCompleted = status == 'completed' || status == 'resulted' || status == 'closed' || status == 'cancelled';

    Map<String, dynamic> prizeBreakdown = {};
    try {
      if (_match!['prize_breakdown'] != null) {
        if (_match!['prize_breakdown'] is String) {
          prizeBreakdown = jsonDecode(_match!['prize_breakdown']);
        } else if (_match!['prize_breakdown'] is Map) {
          prizeBreakdown = Map<String, dynamic>.from(_match!['prize_breakdown']);
        }
      }
    } catch (_) {}

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: kInk), onPressed: () => Navigator.pop(context)),
        title: Text('Contest Details #${widget.tournamentId.substring(0, 6)}', style: const TextStyle(color: kInk, fontWeight: FontWeight.bold, fontSize: 16)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: bannerUrl.isNotEmpty
                  ? Image.network(bannerUrl, height: 180, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _buildDefaultBanner())
                  : _buildDefaultBanner(),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Time Left:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                Text(_formatDuration(_timeLeft), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: kIndigo)),
              ]),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE2E8F0))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('🏆 $title', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: kIndigo)),
                const SizedBox(height: 4),
                const Text('Get ready for the ultimate action and win exciting rewards!', style: TextStyle(fontSize: 11, color: kGrey, fontWeight: FontWeight.w500)),
              ]),
            ),
            const SizedBox(height: 14),
            Row(children: [_specBox('Team', gameMode), const SizedBox(width: 8), _specBox('Mode', gameMode), const SizedBox(width: 8), _specBox('Map', mapName)]),
            const SizedBox(height: 10),
            Row(children: [_specBox('Match Type', entryFee == 0 ? 'Free' : 'Paid'), const SizedBox(width: 8), _specBox('Entry Fee', entryFee == 0 ? 'FREE' : '₹${entryFee.toStringAsFixed(0)}')]),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
              child: Row(children: [
                const Text('Match Schedule: ', style: TextStyle(fontSize: 12, color: kGrey, fontWeight: FontWeight.w500)),
                Text(formatDt(_match!['start_time']), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kInk)),
              ]),
            ),
            const SizedBox(height: 20),
            if (prizeBreakdown.isNotEmpty) ...[
              const Text('Prize Details', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: Colors.blue)),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFCBD5E1))),
                child: Column(children: [
                  for (var entry in prizeBreakdown.entries)
                    Padding(padding: const EdgeInsets.only(bottom: 8.0), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text('${entry.key}:', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kInk)),
                      Text('₹${entry.value}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: kInk)),
                    ])),
                ]),
              ),
              const SizedBox(height: 20),
            ],
            const Text('Rules and Regulations', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: Colors.blue)),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFFF3F0FF), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFD8B4FE))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Center(child: Text('Instructions Before Joining :', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: kInk))),
                const Divider(height: 20, color: Color(0xFFE9D5FF)),
                _ruleBullet('Enter your FF MAX account name only (no changes allowed)'),
                _ruleBullet("Don't Put UID/GAME-ID. & Try to use Simple Font in GameName Also."),
                _ruleBullet('Match room ID and password will be sent 8-10 minutes before the match'),
                _ruleBullet("Make Sure Don't Use Double Vector & M79"),
              ]),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity, height: 44,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(backgroundColor: const Color(0xFFFEF08A), side: const BorderSide(color: Color(0xFFEAB308)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ViewJoiningsScreen(tournamentId: widget.tournamentId))),
                child: const Text('VIEW ALL JOININGS', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF854D0E), fontSize: 12)),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity, height: 46,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: isCompleted ? kGrey : (_joined ? const Color(0xFF059669) : const Color(0xFF84CC16)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0),
                onPressed: isCompleted ? null : (_joined ? null : _openSlotSelectionScreen),
                child: Text(isCompleted ? 'MATCH ${status.toUpperCase()}' : (_joined ? 'JOINED MATCH ✓' : 'Join Match 🚀'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _specBox(String label, String value) {
    return Expanded(child: Container(padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFCBD5E1))), child: Column(children: [Text(label, style: const TextStyle(fontSize: 10, color: kGrey, fontWeight: FontWeight.w500)), const SizedBox(height: 2), Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kInk), maxLines: 1, overflow: TextOverflow.ellipsis)])));
  }

  Widget _ruleBullet(String text) {
    return Padding(padding: const EdgeInsets.only(bottom: 6.0), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('• ', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF7E22CE))), Expanded(child: Text(text, style: const TextStyle(fontSize: 11, color: Color(0xFF334155), fontWeight: FontWeight.w500, height: 1.4)))]));
  }

  Widget _buildDefaultBanner() {
    return Container(height: 180, width: double.infinity, color: const Color(0xFFE2E8F0), child: const Center(child: Icon(Icons.sports_esports_rounded, color: Color(0xFF64748B), size: 48)));
  }
}
