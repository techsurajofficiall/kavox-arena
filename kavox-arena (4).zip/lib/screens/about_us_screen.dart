import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme.dart';

class AboutUsScreen extends StatelessWidget {
  const AboutUsScreen({super.key});

  Future<void> _openUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $urlString');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kInk),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'About Us',
          style: TextStyle(
            color: kInk,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // About Us - Kavox Arena
            _buildSectionCard(
              emoji: '🎮',
              emojiBgColor: Colors.indigo.withOpacity(0.1),
              title: 'ABOUT US — KAVOX ARENA',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Welcome to Kavox Arena, the ultimate destination for competitive gaming, Free Fire eSports tournaments, and buying online game coins like diamonds!',
                    style: TextStyle(fontSize: 13, color: kInk, height: 1.5),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'We are dedicated to creating a fair, transparent, and exciting platform where gamers can test their skills, showcase their talent, and win exciting rewards.',
                    style: TextStyle(fontSize: 13, color: kInk, height: 1.5),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Our Mission
            _buildSectionCard(
              emoji: '🎯',
              emojiBgColor: Colors.amber.withOpacity(0.15),
              title: 'OUR MISSION',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'At Kavox Arena, our mission is simple — to empower gamers by providing a reliable and engaging platform to compete in organized tournaments and leagues.',
                    style: TextStyle(fontSize: 13, color: kInk, height: 1.5),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'We aim to bring players together, promote fair play, and help aspiring eSports enthusiasts rise to the next level.',
                    style: TextStyle(fontSize: 13, color: kInk, height: 1.5),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // What We Offer
            _buildSectionCard(
              emoji: '🕹️',
              emojiBgColor: Colors.purple.withOpacity(0.15),
              title: 'WHAT WE OFFER',
              content: Column(
                children: [
                  _offerTile(
                    '🏆 Regular Tournaments',
                    'Daily matches across multiple game modes including 1v1, 2v2, Clash Squad 4v4, and Per-Kill battles.',
                  ),
                  _offerTile(
                    '🛡️ Secure Platform',
                    'Safe gameplay with proper room validation and verified participants.',
                  ),
                  _offerTile(
                    '⚖️ Fair Play Rules',
                    'Transparent guidelines to ensure equal opportunities for every player.',
                  ),
                  _offerTile(
                    '💰 Instant Rewards',
                    'Win exciting prizes, bonuses, and fast withdrawals for top performance.',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Our Commitment
            _buildSectionCard(
              emoji: '🤝',
              emojiBgColor: Colors.green.withOpacity(0.15),
              title: 'OUR COMMITMENT',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'We believe in building a community where every gamer — casual or professional — feels valued and respected.',
                    style: TextStyle(fontSize: 13, color: kInk, height: 1.5),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Our team continuously works to improve gameplay experience, maintain integrity, and provide fast and reliable customer support.',
                    style: TextStyle(fontSize: 13, color: kInk, height: 1.5),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Connect With Us (Social Buttons)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FE),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kBorder),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: kIndigo.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.headset_mic_outlined, color: kIndigo, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'Connect With Us',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: kInk),
                          ),
                          Text(
                            'Follow us for updates & support',
                            style: TextStyle(fontSize: 11, color: kGrey),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      // Instagram Button
                      Expanded(
                        child: InkWell(
                          onTap: () => _openUrl('https://www.instagram.com/kavoxarena?igsi=ZzFhcDZhcGo0MmI5'),
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.pink.shade50,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.pink.shade200),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.camera_alt, size: 16, color: Colors.pink),
                                SizedBox(width: 6),
                                Text(
                                  'Instagram',
                                  style: TextStyle(color: Colors.pink, fontWeight: FontWeight.bold, fontSize: 13),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Telegram Button
                      Expanded(
                        child: InkWell(
                          onTap: () => _openUrl('https://t.me/kavoxarena_support'),
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.lightBlue.shade50,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.lightBlue.shade200),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.send, size: 16, color: Colors.lightBlue),
                                SizedBox(width: 6),
                                Text(
                                  'Telegram',
                                  style: TextStyle(color: Colors.lightBlue, fontWeight: FontWeight.bold, fontSize: 13),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Get in Touch
            _buildSectionCard(
              emoji: '📬',
              emojiBgColor: Colors.lightBlue.withOpacity(0.15),
              title: 'GET IN TOUCH',
              content: const Text(
                'Have questions, suggestions, or partnership ideas? We\'d love to hear from you! Reach out via Telegram or Instagram support.',
                style: TextStyle(fontSize: 13, color: kInk, height: 1.5),
              ),
            ),
            const SizedBox(height: 24),

            // Footer Tagline & Version
            const Text(
              'Play. Compete. Rise. 🚀',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: kIndigo),
            ),
            const SizedBox(height: 4),
            const Text(
              'Kavox Arena v1.0.0',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kGrey),
            ),
            const SizedBox(height: 2),
            const Text(
              'All Rights Reserved © 2026 — Developed by Kavox Team',
              style: TextStyle(fontSize: 10, color: kGrey),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required String emoji,
    required Color emojiBgColor,
    required String title,
    required Widget content,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: emojiBgColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(emoji, style: const TextStyle(fontSize: 14)),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: kInk,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }

  Widget _offerTile(String title, String desc) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FE),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: kInk)),
          const SizedBox(height: 2),
          Text(desc, style: const TextStyle(fontSize: 11, color: kGrey, height: 1.3)),
        ],
      ),
    );
  }
}