import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/helpers.dart';
import '../core/theme.dart';
import 'wallet_screen.dart';
import 'my_matches_screen.dart';
import 'contests_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String get _uid => sb.auth.currentUser?.id ?? '';
  
  late final Stream<List<Json>> _me = _uid.isNotEmpty 
      ? sb.from('profiles').stream(primaryKey: ['id']).eq('id', _uid)
      : const Stream.empty();

  final Stream<List<Json>> _cats =
      sb.from('categories').stream(primaryKey: ['name']).order('sort', ascending: true);
  final Stream<List<Json>> _tour = sb.from('tournaments').stream(primaryKey: ['id']);
  final Stream<List<Json>> _ann = sb
      .from('announcements')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false)
      .limit(1);

  final PageController _pageController = PageController();
  Timer? _timer;
  int _currentBannerIndex = 0;
  bool _kicked = false;

  String _getStorageUrl(String fileName) {
    return Supabase.instance.client.storage.from('Kavox-arena').getPublicUrl(fileName);
  }

  late final List<Map<String, String>> _banners = [
    {'title': 'WhatsApp Channel', 'subtitle': 'Join for updates', 'image': _getStorageUrl('whatsapp_banner.webp'), 'color': '0xFF25D366', 'type': 'whatsapp'},
    {'title': 'Customer Support', 'subtitle': '24/7 Live Assistance', 'image': _getStorageUrl('support_banner.webp'), 'color': '0xFF0284C7', 'type': 'support'},
    {'title': 'YouTube Channel', 'subtitle': 'Watch highlights & streams', 'image': _getStorageUrl('youtube_banner.webp'), 'color': '0xFFEF4444', 'type': 'youtube'},
    {'title': 'Instant Withdrawal', 'subtitle': 'Fast & secure payouts', 'image': _getStorageUrl('withdrawal_banner.webp'), 'color': '0xFF6366F1', 'type': 'wallet'},
  ];

  late final Map<String, String> _catImages = {
    'BR SURVIVAL': _getStorageUrl('br_survival.webp'),
    'PER KILL MATCHES': _getStorageUrl('per_kill.webp'),
    'CLASH SQUAD 1V1': _getStorageUrl('cs_1v1.webp'),
    'CLASH SQUAD 4V4': _getStorageUrl('class_squad_4v4.webp'),
    'LONE WOLF 1V1': _getStorageUrl('lone_wolf_1v1.webp'),
    'LONE WOLF 2V2': _getStorageUrl('lone_wolf_2v2.webp'),
    'CS HEADSHOT': _getStorageUrl('cs_headshot.webp'),
    'BR SQUAD': _getStorageUrl('br_squad.webp'),
    'ESPORTS SPECIAL': _getStorageUrl('esports_special.webp'),
    'FREE MATCHES': _getStorageUrl('free_tournament.webp'),
  };

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted || !_pageController.hasClients) return;
      final next = (_currentBannerIndex + 1) % _banners.length;
      _pageController.animateToPage(next, duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  Color _parseColor(String? colorStr) {
    if (colorStr == null) return Colors.blue;
    try { return Color(int.parse(colorStr)); } catch (_) { return Colors.blue; }
  }

  Future<void> _launchURL(String url) async {
    try { await launchUrlString(url, mode: LaunchMode.externalApplication); } catch (_) {
      try { await launchUrlString(url, mode: LaunchMode.externalNonBrowserApplication); } catch (_) {}
    }
  }

  void _handleBannerTap(String type) async {
    if (type == 'whatsapp') { await _launchURL('https://whatsapp.com/channel/0029VbDZBHt17Emzw6h7z30m'); }
    else if (type == 'youtube') { await _launchURL('https://www.youtube.com/@KavoxArena'); }
    else if (type == 'support') {
      showModalBottomSheet(context: context, backgroundColor: Colors.white, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        builder: (context) => Padding(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Customer Support', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
            const SizedBox(height: 6), const Text('Choose your preferred support channel:', style: TextStyle(fontSize: 12, color: Colors.grey)), const SizedBox(height: 20),
            ListTile(leading: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFFE0F2FE), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.send_rounded, color: Color(0xFF0284C7), size: 24)), title: const Text('Telegram Support', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)), trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey), onTap: () async { Navigator.pop(context); await _launchURL('https://t.me/kavoxarena_support'); }),
            const Divider(height: 16),
            ListTile(leading: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)]), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 24)), title: const Text('Instagram Support', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)), trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey), onTap: () async { Navigator.pop(context); await _launchURL('https://www.instagram.com/kavoxarena'); }),
          ])));
    } else if (type == 'wallet') { Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: StreamBuilder<List<Json>>(
                stream: _me,
                builder: (context, s) {
                  final p = (s.data?.isNotEmpty ?? false) ? s.data!.first : null;
                  if (p != null && p['status'] == 'banned' && !_kicked) {
                    _kicked = true;
                    WidgetsBinding.instance.addPostFrameCallback((_) => sb.auth.signOut());
                  }
                  final total = p == null ? 0.0 : dbl(p['deposit_balance']) + dbl(p['winning_balance']);
                  return Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(22),
                        child: CachedNetworkImage(
                          imageUrl: _getStorageUrl('kavox_icon.webp'),
                          width: 42, height: 42, fit: BoxFit.cover,
                          placeholder: (c,u) => Container(width:42,height:42,color: const Color(0xFFE2E8F0)),
                          errorWidget: (c,u,e) => Container(width:42,height:42,decoration: const BoxDecoration(color: kIndigo, shape: BoxShape.circle), child: const Icon(Icons.sports_esports, color: Colors.white, size: 22)),
                        ),
                      ),
                      const SizedBox(width:12),
                      const Expanded(child: Text('KAVOX ARENA', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: kInk, letterSpacing: 1.1))),
                      GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(gradient: const LinearGradient(colors: [kIndigo, kViolet]), borderRadius: BorderRadius.circular(20)),
                          child: Row(children: [
                            const Icon(Icons.account_balance_wallet, color: Colors.white, size: 16),
                            const SizedBox(width: 6),
                            Text('₹${money(total)}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                          ]),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    StreamBuilder<List<Json>>(
                      stream: _ann,
                      builder: (context, s) {
                        final a = (s.data?.isNotEmpty ?? false) ? s.data!.first : null;
                        if (a == null) return const SizedBox.shrink();
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE2E8F0))),
                          child: Row(children: [
                            const Icon(Icons.campaign, color: Colors.amber, size: 18),
                            const SizedBox(width: 10),
                            Expanded(child: Text('${a['title'] ?? 'Announcement'}: ${a['message'] ?? ''}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF1F2937)), maxLines: 1, overflow: TextOverflow.ellipsis)),
                          ]),
                        );
                      },
                    ),
                    Container(
                      height: 150,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 6, offset: const Offset(0, 3))]),
                      child: Stack(children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: PageView.builder(
                            controller: _pageController,
                            itemCount: _banners.length,
                            onPageChanged: (i) => setState(() => _currentBannerIndex = i),
                            itemBuilder: (context, i) {
                              final b = _banners[i];
                              return GestureDetector(
                                onTap: () => _handleBannerTap(b['type']!),
                                child: Stack(fit: StackFit.expand, children: [
                                  CachedNetworkImage(imageUrl: b['image']!, fit: BoxFit.cover, placeholder: (c,u) => Container(color: _parseColor(b['color'])), errorWidget: (c,u,e) => Container(color: _parseColor(b['color']))),
                                  Container(color: Colors.black.withOpacity(0.15)),
                                  Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(b['title']!, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(b['subtitle']!, style: const TextStyle(color: Colors.white70, fontSize: 12))])),
                                ]),
                              );
                            },
                          ),
                        ),
                        Positioned(bottom: 10, left: 0, right: 0, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (var i = 0; i < _banners.length; i++) AnimatedContainer(duration: const Duration(milliseconds: 250), margin: const EdgeInsets.symmetric(horizontal: 3), width: i == _currentBannerIndex ? 18 : 6, height: 6, decoration: BoxDecoration(color: i == _currentBannerIndex ? Colors.white : Colors.white54, borderRadius: BorderRadius.circular(3)))])),
                      ]),
                    ),
                    const SizedBox(height: 16),
                    const Text('MY MATCHES', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
                    const SizedBox(height: 8),
                    Row(children: [
                      _buildMatchCard('Ongoing', Icons.autorenew, const Color(0xFF10B981), 1),
                      const SizedBox(width: 8),
                      _buildMatchCard('Upcoming', Icons.calendar_today, const Color(0xFF0EA5E9), 0),
                      const SizedBox(width: 8),
                      _buildMatchCard('Completed', Icons.check_circle, const Color(0xFF10B981), 2),
                    ]),
                    const SizedBox(height: 16),
                    const Text('ESPORTS GAMES', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF64748B))),
                    const SizedBox(height: 8),
                    StreamBuilder<List<Json>>(
                      stream: _cats,
                      initialData: const [
                        {'name': 'BR SURVIVAL', 'sort': 1},
                        {'name': 'PER KILL MATCHES', 'sort': 2},
                        {'name': 'CLASH SQUAD 1V1', 'sort': 3},
                        {'name': 'CLASH SQUAD 4V4', 'sort': 4},
                        {'name': 'LONE WOLF 1V1', 'sort': 5},
                        {'name': 'LONE WOLF 2V2', 'sort': 6},
                        {'name': 'CS HEADSHOT', 'sort': 7},
                        {'name': 'BR SQUAD', 'sort': 8},
                        {'name': 'ESPORTS SPECIAL', 'sort': 9},
                        {'name': 'FREE MATCHES', 'sort': 10},
                      ],
                      builder: (context, cs) {
                        return StreamBuilder<List<Json>>(
                          stream: _tour,
                          initialData: const [],
                          builder: (context, ts) {
                            final tours = ts.data ?? <Json>[];
                            final cats = cs.data ?? [];
                            return GridView.count(
                              crossAxisCount: 2,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 10,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              childAspectRatio: 1.05,
                              children: [
                                for (final c in cats)
                                  _buildGameCard(
                                    '${c['name']}',
                                    tours.where((t) => t['category'] == c['name'] && t['status'] == 'upcoming').length,
                                    _catImages[c['name']] ?? '',
                                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContestsScreen(category: c['name']))),
                                  ),
                              ],
                            );
                          },
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMatchCard(String title, IconData icon, Color color, int initialTab) {
    return Expanded(child: GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MyMatchesScreen(initialTabIndex: initialTab))), child: Container(padding: const EdgeInsets.symmetric(vertical: 10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE2E8F0))), child: Column(children: [Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: Colors.white, size: 14)), const SizedBox(height: 4), Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1F2937)))]))));
  }

  Widget _buildGameCard(String title, int matchCount, String imagePath, VoidCallback onTap) {
    return GestureDetector(onTap: onTap,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE2E8F0))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(child: imagePath.isNotEmpty ? CachedNetworkImage(imageUrl: imagePath, width: double.infinity, fit: BoxFit.cover, placeholder: (c,u) => Container(color: const Color(0xFFE2E8F0)), errorWidget: (c,u,e) => Container(color: const Color(0xFFE2E8F0), child: const Center(child: Icon(Icons.sports_esports, color: Color(0xFF64748B), size: 28)))) : Container(color: const Color(0xFFE2E8F0), child: const Center(child: Icon(Icons.sports_esports, color: Color(0xFF64748B), size: 28)))),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Expanded(child: Text(title, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF1F2937)), maxLines: 1, overflow: TextOverflow.ellipsis)),
              Row(children: [
                Container(width: 6, height: 6, decoration: BoxDecoration(color: matchCount > 0 ? const Color(0xFF10B981) : const Color(0xFF94A3B8), shape: BoxShape.circle)),
                const SizedBox(width: 4),
                Text(matchCount > 0 ? '$matchCount' : '--', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: matchCount > 0 ? const Color(0xFF10B981) : const Color(0xFF94A3B8))),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}