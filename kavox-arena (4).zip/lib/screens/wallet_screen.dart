import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  double _depositBalance = 0.0;
  double _winningBalance = 0.0;
  bool _loading = true;
  List<dynamic> _transactions = [];

  @override
  void initState() {
    super.initState();
    _fetchWalletData();
  }

  Future<void> _fetchWalletData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      final res = await Supabase.instance.client
          .from('profiles')
          .select('deposit_balance, winning_balance')
          .eq('id', user.id)
          .maybeSingle();

      if (res != null) {
        setState(() {
          _depositBalance = dbl(res['deposit_balance']);
          _winningBalance = dbl(res['winning_balance']);
        });
      }

      // Fetch transaction history
      final txRes = await Supabase.instance.client
          .from('transactions')
          .select()
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(10);

      setState(() {
        _transactions = txRes;
      });
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showTopAlert(String message, {bool isError = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(isError ? Icons.error_outline : Icons.check_circle_outline, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(child: Text(message, style: const TextStyle(fontWeight: FontWeight.bold))),
          ],
        ),
        backgroundColor: isError ? kRed : const Color(0xFF059669),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _openAddCashDialog() {
    final amountController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
          left: 20,
          right: 20,
          top: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ADD CASH', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: kInk)),
            const SizedBox(height: 12),
            const Text('Min: ₹20 | Max: ₹5000', style: TextStyle(fontSize: 12, color: kGrey)),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'Enter amount (₹20 - ₹5000)',
                prefixText: '₹ ',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              children: [20, 50, 100, 500, 1000, 5000].map((amt) {
                return OutlinedButton(
                  onPressed: () => amountController.text = amt.toString(),
                  child: Text('₹$amt'),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: kIndigo, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                onPressed: () {
                  final amt = double.tryParse(amountController.text) ?? 0;
                  if (amt < 20 || amt > 5000) {
                    _showTopAlert('Invalid Amount! Please enter between ₹20 and ₹5000.');
                    return;
                  }
                  Navigator.pop(ctx);
                  _openQrPaymentScreen(amt);
                },
                child: const Text('PROCEED TO PAY', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _openQrPaymentScreen(double amount) {
    final utrController = TextEditingController();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(title: const Text('SECURE PAYMENT'), backgroundColor: Colors.white, elevation: 0),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: const Color(0xFFF8F9FE), borderRadius: BorderRadius.circular(16), border: Border.all(color: kBorder)),
                  child: Column(
                    children: [
                      const Text('PAYING TO KAVOX ARENA', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                      const SizedBox(height: 6),
                      Text('₹${amount.toStringAsFixed(2)}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: kInk)),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                // QR Container
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: kBorder)),
                  child: Column(
                    children: [
                      const Text('SCAN TO PAY INSTANTLY', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                      const SizedBox(height: 12),
                      Container(
                        width: 200,
                        height: 200,
                        color: Colors.grey[200],
                        child: const Center(child: Icon(Icons.qr_code_2, size: 150, color: kInk)),
                      ),
                      const SizedBox(height: 12),
                      const Text('surajnegi07@nyes', style: TextStyle(fontWeight: FontWeight.bold, color: kIndigo)),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                // UTR INPUT (Fully visible & upfront)
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('AFTER PAYMENT, ENTER UTR', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kIndigo)),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: utrController,
                        keyboardType: TextInputType.number,
                        maxLength: 12,
                        decoration: InputDecoration(
                          counterText: '',
                          hintText: 'Enter 12-Digit UTR / Ref',
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: kGrey.withOpacity(0.2)),
                      onPressed: () async {
                        final data = await Clipboard.getData('text/plain');
                        if (data != null && data.text != null) {
                          utrController.text = data.text!.trim();
                        }
                      },
                      child: const Text('PASTE', style: TextStyle(color: kInk, fontSize: 12)),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF059669),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () async {
                      if (utrController.text.trim().length != 12) {
                        _showTopAlert('Please enter a valid 12-digit UTR number!');
                        return;
                      }
                      // Submit deposit request logic to Supabase
                      Navigator.pop(context);
                      _showTopAlert('Deposit request submitted successfully!', isError: false);
                    },
                    child: const Text('VERIFY & SUBMIT DEPOSIT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openWithdrawDialog() {
    final amountController = TextEditingController();
    final upiController = TextEditingController();
    final nameController = TextEditingController();
    final pinController = TextEditingController();
    bool isConfirmed = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
            left: 20,
            right: 20,
            top: 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('WITHDRAW WINNINGS', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: kInk)),
                const SizedBox(height: 8),
                Text('Available Winnings: ₹${_winningBalance.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12, color: kGrey)),
                const SizedBox(height: 16),
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: 'Enter amount (Min ₹50, Max ₹5000)',
                    prefixText: '₹ ',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  children: [50, 100, 200, 500, 1000].map((amt) {
                    return OutlinedButton(
                      onPressed: () => amountController.text = amt.toString(),
                      child: Text('₹$amt'),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: upiController,
                  decoration: InputDecoration(
                    hintText: 'UPI ID (e.g. username@oksbi)',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    hintText: 'Account Holder Name (as per UPI)',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: pinController,
                  obscureText: true,
                  maxLength: 4,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    counterText: '',
                    hintText: 'Enter 4-Digit Security PIN',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Checkbox(
                      value: isConfirmed,
                      onChanged: (val) => setModalState(() => isConfirmed = val ?? false),
                    ),
                    const Expanded(
                      child: Text('I confirm this UPI ID is mine. I am responsible for any wrong details.', style: TextStyle(fontSize: 12, color: kInk)),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kRed,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () {
                      final amt = double.tryParse(amountController.text) ?? 0;
                      if (amt < 50 || amt > 5000) {
                        _showTopAlert('Min withdrawal is ₹50 and max is ₹5000.');
                        return;
                      }
                      if (amt > _winningBalance) {
                        _showTopAlert('Insufficient winning balance!');
                        return;
                      }
                      if (upiController.text.trim().isEmpty || !upiController.text.contains('@')) {
                        _showTopAlert('Please enter a valid UPI ID.');
                        return;
                      }
                      if (nameController.text.trim().isEmpty) {
                        _showTopAlert('Please enter Account Holder Name.');
                        return;
                      }
                      if (pinController.text.trim().length != 4) {
                        _showTopAlert('Please enter your 4-digit security PIN.');
                        return;
                      }
                      if (!isConfirmed) {
                        _showTopAlert('Please confirm ownership checkbox.');
                        return;
                      }

                      Navigator.pop(ctx);
                      _showTopAlert('Withdrawal request placed successfully!', isError: false);
                    },
                    child: const Text('REQUEST WITHDRAWAL', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalBalance = _depositBalance + _winningBalance;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Wallet', style: TextStyle(color: kInk, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kIndigo))
          : RefreshIndicator(
              onRefresh: _fetchWalletData,
              color: kIndigo,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // Balance Card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [kIndigo, Color(0xFF8B5CF6)]),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Total Balance', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          const SizedBox(height: 4),
                          Text('₹${totalBalance.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('Deposit', style: TextStyle(color: Colors.white70, fontSize: 11)),
                                      const SizedBox(height: 2),
                                      Text('₹${_depositBalance.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('Winnings', style: TextStyle(color: Colors.white70, fontSize: 11)),
                                      const SizedBox(height: 2),
                                      Text('₹${_winningBalance.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Action Buttons (Add Cash & Withdraw)
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: kIndigo,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            onPressed: _openAddCashDialog,
                            child: const Text('ADD CASH', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: kIndigo, width: 1.5),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            onPressed: _openWithdrawDialog,
                            child: const Text('WITHDRAW', style: TextStyle(color: kIndigo, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Transactions Header
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text('TRANSACTIONS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                    ),
                    const SizedBox(height: 12),

                    // Transaction List
                    _transactions.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.only(top: 40),
                            child: Text('No transactions yet', style: TextStyle(color: kGrey)),
                          )
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: _transactions.length,
                            itemBuilder: (ctx, i) {
                              final tx = _transactions[i];
                              return Container(
                                margin: const EdgeInsets.only(bottom: 10),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: kBorder),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(tx['type'] ?? 'Transaction', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: kInk)),
                                        const SizedBox(height: 2),
                                        Text(tx['created_at']?.substring(0, 10) ?? '', style: const TextStyle(fontSize: 11, color: kGrey)),
                                      ],
                                    ),
                                    Text('₹${tx['amount']}', style: const TextStyle(fontWeight: FontWeight.bold, color: kIndigo)),
                                  ],
                                ),
                              );
                            },
                          ),
                  ],
                ),
              ),
            ),
    );
  }
}
