import 'package:flutter/material.dart';

import '../core/theme.dart';

// ───────── Colors (PHP pages jaise) ─────────
const _purple = Color(0xFF9333EA);
const _orange = Color(0xFFEA580C);
const _blue = Color(0xFF2563EB);
const _rose = Color(0xFFE11D48);

class _Rule {
  final IconData icon;
  final Color color;
  final String title;
  final String tag;
  final List<String> lines;
  final bool bullets;
  final bool warning;

  _Rule(
    this.icon,
    this.color,
    this.title,
    this.tag,
    this.lines, {
    this.bullets = false,
    this.warning = false,
  });
}

// ═════════════════════════ TERMS & CONDITIONS ═════════════════════════

final List<_Rule> _termsRules = [
  _Rule(Icons.how_to_reg, kIndigo, 'Eligibility (18+ Age Requirement)', 'Rule #1', [
    'By registering on and using this platform, you confirm that you are at least 18 years of age. Participation in any match, contest, or paid activity is strictly restricted to users who meet this minimum age requirement. The platform reserves the right to suspend or terminate accounts found to be in violation of this condition without prior notice.',
  ]),
  _Rule(Icons.block, kRed, 'No Cancellation After Entry', 'Rule #2', [
    'Users cannot cancel their entry once they have joined any paid match.',
  ]),
  _Rule(Icons.schedule, kAmber, 'Late Entry Policy', 'Rule #3', [
    'If you fail to enter the match before the given match start time, you will not be eligible for a refund.',
  ]),
  _Rule(Icons.security, _purple, 'Anti-Cheat Policy', 'Rule #4', [
    'If you are found using any kind of hack or team-up technique, your account will be blocked and you will not get any kind of withdrawal or refund.',
  ]),
  _Rule(Icons.warning_amber, _orange, 'Multiple Account Policy', 'Rule #5', [
    'Using multiple IDs on our app is prohibited. If you are found using multiple IDs, we will ban your ID from our app.',
  ]),
  _Rule(Icons.payments, kGreen, 'Match Cancellation & Refund Policy', 'Rule #6', [
    'If any match is cancelled for any reason from our side, users will get their match fee refunded to their account.',
  ]),
  // ───── Neeche ke rules naye jode gaye hain ─────
  _Rule(Icons.account_balance_wallet, _blue, 'Wallet & Payments', 'Rule #7', [
    'Cash is added to your wallet only after our team verifies your payment (UTR / transaction ID).',
    'Entry fees are deducted from your deposit balance first, then from your winning balance.',
    'Only your winning balance can be withdrawn. The minimum withdrawal is ₹30.',
    'Fake, wrong or repeated UTR submissions will be rejected and may lead to a permanent ban.',
  ], bullets: true),
  _Rule(Icons.videocam, _rose, 'Game Details & Screen Recording', 'Rule #8', [
    'Play only with your own Free Fire account and enter your exact in-game name while joining. Players may be asked for screen recording as proof; refusing can lead to a penalty or ban as per the match rules.',
  ]),
  _Rule(Icons.vpn_key, _blue, 'Room ID & Password', 'Rule #9', [
    'Room details are only for registered players of that match. Sharing, selling or leaking them will lead to a ban.',
  ]),
  _Rule(Icons.group_add, kGreen, 'Referral Program', 'Rule #10', [
    'Self-referral, fake accounts or any misuse of referral codes will cancel the rewards, and the accounts involved may be banned.',
  ]),
  _Rule(Icons.lock, _orange, 'Account Security', 'Rule #11', [
    "You are responsible for keeping your username and password safe. Do not share them with anyone. KAVOX ARENA is not responsible for losses caused by shared or stolen login details.",
  ]),
  _Rule(Icons.support_agent, kAmber, 'Support & Disputes', 'Rule #12', [
    "Raise any issue with customer support within 2 hours of the match end time. Support is available from 10 AM to 10 PM. KAVOX ARENA's decision on disputes will be final.",
  ]),
  _Rule(Icons.gavel, _purple, 'Applicable Laws', 'Rule #13', [
    'You are responsible for making sure that your participation is allowed under the laws that apply to you. KAVOX ARENA may restrict or refuse access to any user where required by law.',
  ]),
  _Rule(Icons.update, kIndigo, 'Changes to These Terms', 'Rule #14', [
    'These terms can be updated at any time. If you keep using the app after an update, it means you accept the new terms.',
  ]),
];

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _InfoPage(
      title: 'Terms & Conditions',
      badge: 'Legal',
      badgeIcon: Icons.balance,
      heading: 'User Agreement',
      sub: 'Please read these terms carefully before participating',
      rules: _termsRules,
      noticeTitle: 'Important Notice',
      notice:
          'By participating in any match or contest on our platform, you agree to abide by these terms and conditions. Violation of any of these rules may result in account suspension or permanent ban.',
    );
  }
}

// ═════════════════════════ PRIVACY POLICY ═════════════════════════

final List<_Rule> _privacyRules = [
  _Rule(Icons.block, kRed, 'Match Cancellation Policy', 'Policy #1', [
    'KAVOX ARENA reserves the right to cancel any match at any time without any reason.',
  ]),
  _Rule(Icons.how_to_reg, kIndigo, 'Age Requirement', 'Policy #2', [
    'By participating in KAVOX ARENA matches, you accept and agree that you are above 18 years of age.',
  ]),
  _Rule(Icons.person_search, kAmber, 'Suspicious Activity', 'Policy #3', [
    "In case the investigators or spectators find any suspicious player in the gameplay, KAVOX ARENA reserves the right to disqualify, suspend or put the player's account on hold, and also cancel their winning prizes or amount.",
  ]),
  _Rule(Icons.warning_amber, _orange, 'Multiple Account Policy', 'Policy #4', [
    'If we find you using multiple IDs, you will be banned from our app.',
  ], warning: true),
  _Rule(Icons.build, _blue, 'Technical Issues', 'Policy #5', [
    'In case of any technical glitch, the match may get cancelled, and in such cases the entry fees will be refunded to the participants or a re-match may take place.',
    'In case any player fails to submit correct details while participating in any match, the reward/prize amount will be cancelled for that player and no refund will be processed.',
  ]),
  _Rule(Icons.security, _purple, 'Prohibited Activities', 'Policy #6', [
    'Players are not allowed to use any Mod or Hack in the gameplay. If anyone is found suspicious, immediate action will be taken, the account will be suspended, all pending withdrawals will be cancelled and the wallet balance will become useless.',
    'Misusing any in-game glitches or errors will result in disqualification of that player from the match, and no reward for that match will be considered.',
  ]),
  _Rule(Icons.laptop, _rose, 'Emulator Usage', 'Policy #7', [
    'Do not use any emulator to play in non-emulator matches. Such players will be kicked, and if they remain un-kicked they may not get the match rewards/prizes.',
  ]),
  _Rule(Icons.checklist, kGreen, 'Match Participation Guidelines', 'Policy #8', [
    'Participants must grab the Match Details such as Room ID and Password before the match start time. The Room ID and Password are shared in the app. Join the room quickly. If participants fail to join the room before the match start time, they will not be able to join the match later and no refund will be processed.',
    'If participants fail to join the room due to any issue from their end (slow internet, multi-tasking, minimizing the game, receiving calls or SMS, etc.), no refund will be processed.',
    'If participants are kicked or auto-kicked from the room without any reason, a refund will be issued upon submitting proper valid evidence such as a screenshot of the error screen or message.',
    'Any of the policies mentioned here can change, get updated or removed at any time, so keep checking here for the latest policies and rules.',
  ], bullets: true),
  _Rule(Icons.thumb_up, kIndigo, 'Fair Play Policy', 'Policy #9', [
    'Before participating in any match at KAVOX ARENA, you agree to the Fair Play Policy and accept it.',
  ]),
  // ───── Neeche ke policies naye jode gaye hain ─────
  _Rule(Icons.storage, _blue, 'Information We Collect', 'Policy #10', [
    'Account details: username, name, email address and mobile number.',
    'Game details: the in-game name and Free Fire ID you enter while joining matches.',
    'Activity: matches joined, results, wallet transactions and payment references (UTR / transaction ID).',
  ], bullets: true),
  _Rule(Icons.tune, _orange, 'How We Use Your Information', 'Policy #11', [
    'To create and secure your account and log you in.',
    'To run matches, publish results and credit your winnings.',
    'To verify payments and withdrawals and to prevent fraud or multiple accounts.',
    'To contact you for support or important updates.',
  ], bullets: true),
  _Rule(Icons.lock, kGreen, 'Data Sharing & Security', 'Policy #12', [
    'We do not sell your personal data. We share information only when required by law or to prevent fraud and abuse. Your data is stored on a secure cloud database with access controls. Never share your password or match Room ID/password with anyone.',
  ]),
  _Rule(Icons.delete_outline, _rose, 'Your Rights', 'Policy #13', [
    'You can ask our support team to correct your details or delete your account. Some transaction records may be kept for legal and accounting reasons even after deletion.',
  ]),
];

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _InfoPage(
      title: 'Privacy Policy',
      badge: 'Guidelines',
      badgeIcon: Icons.security,
      heading: 'Platform Policies',
      sub: 'Our core guidelines and terms for KAVOX ARENA',
      rules: _privacyRules,
    );
  }
}

// ═════════════════════════ Shared page layout ═════════════════════════

class _InfoPage extends StatelessWidget {
  final String title;
  final String badge;
  final IconData badgeIcon;
  final String heading;
  final String sub;
  final List<_Rule> rules;
  final String? noticeTitle;
  final String? notice;

  const _InfoPage({
    required this.title,
    required this.badge,
    required this.badgeIcon,
    required this.heading,
    required this.sub,
    required this.rules,
    this.noticeTitle,
    this.notice,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F6),
      appBar: AppBar(
        title: Text(
          title.toUpperCase(),
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.2),
        ),
        actions: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(right: 14),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0x66312E81),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x4D6366F1)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(badgeIcon, size: 12, color: const Color(0xFFA5B4FC)),
                  const SizedBox(width: 4),
                  Text(
                    badge,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFC7D2FE),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Column(
              children: [
                Text(
                  heading.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF111827),
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  sub,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280), fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 16),
                for (final r in rules) _ruleCard(r),
                if (notice != null) _noticeBox(),
                const SizedBox(height: 8),
                const Text(
                  'Kavox Arena v1.0.0',
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Color(0xFF6B7280)),
                ),
                const SizedBox(height: 2),
                const Text(
                  'LAST UPDATED: 10/18/2026',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                    color: Color(0xFF9CA3AF),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _ruleCard(_Rule r) {
    final textStyle = r.warning
        ? const TextStyle(fontSize: 12, height: 1.6, fontWeight: FontWeight.w800, color: kRed)
        : const TextStyle(fontSize: 12, height: 1.6, fontWeight: FontWeight.w500, color: Color(0xFF374151));

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD1D5DB)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 1)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFFE5E7EB),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFFD1D5DB)),
                ),
                child: Icon(r.icon, size: 15, color: r.color),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      r.title.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF111827),
                      ),
                    ),
                    Text(
                      r.tag,
                      style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: r.color),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          for (var i = 0; i < r.lines.length; i++)
            Padding(
              padding: EdgeInsets.only(bottom: i == r.lines.length - 1 ? 0 : 8, left: 4),
              child: r.bullets
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 7, right: 8),
                          child: Container(
                            width: 4,
                            height: 4,
                            decoration: const BoxDecoration(color: Color(0xFF374151), shape: BoxShape.circle),
                          ),
                        ),
                        Expanded(child: Text(r.lines[i], style: textStyle)),
                      ],
                    )
                  : Text(r.lines[i], style: textStyle),
            ),
        ],
      ),
    );
  }

  Widget _noticeBox() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xCCE2E8F0),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFCBD5E1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.assignment, size: 14, color: Color(0xFF4338CA)),
              const SizedBox(width: 8),
              Text(
                (noticeTitle ?? '').toUpperCase(),
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                  color: Color(0xFF111827),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            notice ?? '',
            style: const TextStyle(
              fontSize: 12,
              height: 1.6,
              fontWeight: FontWeight.w500,
              color: Color(0xFF374151),
            ),
          ),
        ],
      ),
    );
  }
}
