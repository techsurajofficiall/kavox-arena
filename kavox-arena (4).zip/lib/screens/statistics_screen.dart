import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  bool _loading = true;
  int _totalMatches = 0;
  int _totalKills = 0;
  double _totalWinnings = 0.0;
  List<dynamic> _history = [];
  String _ign = 'Player';

  @override
  void initState() {
    super.initState();
    _fetchStats();
  }

  Future<void> _fetchStats() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      final profileRes = await Supabase.instance.client
          .from('profiles')
          .select('ign')
          .eq('id', user.id)
          .maybeSingle();

      if (profileRes != null) {
        _ign = profileRes['ign'] ?? 'Player';
      }

      final res = await Supabase.instance.client
          .from('participants')
          .select('*, tournaments(*)')
          .eq('user_id', user.id)
          .order('created_at', ascending: false);

      if (res != null) {
        int matches = res.length;
        int kills = 0;
        double winnings = 0.0;

        for (var item in res) {
          kills += dbl(item['kills']).toInt();
          winnings += dbl(item['winnings']);
        }

        setState(() {
          _totalMatches = matches;
          _totalKills = kills;
          _totalWinnings = winnings;
          _history = res;
        });
      }
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: const BackButton(color: kInk),
        title: const Text('Player Statistics', style: TextStyle(color: kInk, fontWeight: FontWeight.bold, fontSize: 18)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kIndigo))
          : RefreshIndicator(
              onRefresh: _fetchStats,
              color: kIndigo,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Profile IGN Card
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [kIndigo, Color(0xFF8B5CF6)]),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          const CircleAvatar(
                            radius: 28,
                            backgroundColor: Colors.white24,
                            child: Icon(Icons.sports_esports, color: Colors.white, size: 30),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('SAVED IGN', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 2),
                                Text(_ign, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Stats Summary Grid
                    Row(
                      children: [
                        Expanded(child: _statBox('MATCHES', '$_totalMatches', Icons.sports_kabaddi)),
                        const SizedBox(width: 12),
                        Expanded(child: _statBox('TOTAL KILLS', '$_totalKills', Icons.local_fire_department)),
                        const SizedBox(width: 12),
                        Expanded(child: _statBox('WINNINGS', '₹${_totalWinnings.toStringAsFixed(0)}', Icons.emoji_events, isGreen: true)),
                      ],
                    ),
                    const SizedBox(height: 24),

                    const Text('MATCH PERFORMANCE HISTORY', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                    const SizedBox(height: 12),

                    _history.isEmpty
                        ? const Center(
                            child: Padding(
                              padding: EdgeInsets.symmetric(vertical: 40),
                              child: Text('No match history found yet.', style: TextStyle(color: kGrey, fontWeight: FontWeight.bold)),
                            ),
                          )
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: _history.length,
                            itemBuilder: (ctx, i) {
                              final item = _history[i];
                              final t = item['tournaments'] ?? {};
                              final title = t['title'] ?? 'Free Fire Tournament';
                              final kills = dbl(item['kills']).toInt();
                              final winnings = dbl(item['winnings']);
                              final slotNo = item['slot_no'] ?? '-';

                              return Container(
                                margin: const EdgeInsets.only(bottom: 12),
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: kBorder),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: kInk), maxLines: 1, overflow: TextOverflow.ellipsis),
                                          const SizedBox(height: 4),
                                          Text('Slot #$slotNo', style: const TextStyle(fontSize: 11, color: kGrey, fontWeight: FontWeight.w500)),
                                        ],
                                      ),
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text('$kills Kills', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: kIndigo)),
                                        const SizedBox(height: 2),
                                        Text('₹${winnings.toStringAsFixed(0)}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: winnings > 0 ? const Color(0xFF059669) : kGrey)),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _statBox(String label, String value, IconData icon, {bool isGreen = false}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FE),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: isGreen ? const Color(0xFF059669) : kIndigo),
          const SizedBox(height: 10),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: isGreen ? const Color(0xFF059669) : kInk)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: kGrey)),
        ],
      ),
    );
  }
}
