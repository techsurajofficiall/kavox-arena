import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme.dart';

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  static Future<void> _openUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $urlString');
    }
  }

  // Pure App me kahin bhi popup call karne ke liye helper method
  static void showContactPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
        contentPadding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.headset_mic, color: Colors.green, size: 18),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Select Support Channel',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: kInk,
                  ),
                ),
              ],
            ),
            InkWell(
              onTap: () => Navigator.pop(ctx),
              borderRadius: BorderRadius.circular(15),
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.close, size: 16, color: kGrey),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 1. Telegram Support (Main)
            _channelTile(
              title: 'Telegram Support (Main)',
              subtitle: 'Fastest response via Telegram',
              icon: Icons.send,
              color: Colors.blue,
              onTap: () {
                Navigator.pop(ctx);
                _openUrl('https://t.me/kavoxarena_support');
              },
            ),
            const SizedBox(height: 10),

            // 2. Instagram Support
            _channelTile(
              title: 'Instagram Support',
              subtitle: 'Connect via Instagram DM',
              icon: Icons.camera_alt,
              color: Colors.pink,
              onTap: () {
                Navigator.pop(ctx);
                _openUrl('https://www.instagram.com/kavoxarena?igsi=ZzFhcDZhcGo0MmI5');
              },
            ),
            const SizedBox(height: 10),

            // 3. WhatsApp Channel
            _channelTile(
              title: 'WhatsApp Channel',
              subtitle: 'Join for updates & announcements',
              icon: Icons.chat,
              color: Colors.green,
              onTap: () {
                Navigator.pop(ctx);
                _openUrl('https://whatsapp.com/channel/0029VbDZBHt17Emzw6h7z30m');
              },
            ),
            const SizedBox(height: 10),

            // 4. YouTube Channel (Active Link)
            _channelTile(
              title: 'YouTube Channel',
              subtitle: 'Watch latest matches & updates',
              icon: Icons.play_arrow,
              color: Colors.red,
              onTap: () {
                Navigator.pop(ctx);
                _openUrl('https://www.youtube.com/@KavoxArena');
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kInk),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Contact Us',
          style: TextStyle(
            color: kInk,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: kBorder),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: Colors.green.shade50,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.headset_mic, color: Colors.green, size: 18),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'Select Support Channel',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: kInk,
                          ),
                        ),
                      ],
                    ),
                    InkWell(
                      onTap: () => Navigator.pop(context),
                      borderRadius: BorderRadius.circular(15),
                      child: Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.close, size: 16, color: kGrey),
                      ),
                    ),
                  ],
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Divider(height: 1, color: kBorder),
                ),
                _channelTile(
                  title: 'Telegram Support (Main)',
                  subtitle: 'Fastest response via Telegram',
                  icon: Icons.send,
                  color: Colors.blue,
                  onTap: () => _openUrl('https://t.me/kavoxarena_support'),
                ),
                const SizedBox(height: 10),
                _channelTile(
                  title: 'Instagram Support',
                  subtitle: 'Connect via Instagram DM',
                  icon: Icons.camera_alt,
                  color: Colors.pink,
                  onTap: () => _openUrl('https://www.instagram.com/kavoxarena?igsi=ZzFhcDZhcGo0MmI5'),
                ),
                const SizedBox(height: 10),
                _channelTile(
                  title: 'WhatsApp Channel',
                  subtitle: 'Join for updates & announcements',
                  icon: Icons.chat,
                  color: Colors.green,
                  onTap: () => _openUrl('https://whatsapp.com/channel/0029VbDZBHt17Emzw6h7z30m'),
                ),
                const SizedBox(height: 10),
                _channelTile(
                  title: 'YouTube Channel',
                  subtitle: 'Watch latest matches & updates',
                  icon: Icons.play_arrow,
                  color: Colors.red,
                  onTap: () => _openUrl('https://www.youtube.com/@KavoxArena'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static Widget _channelTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required MaterialColor color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF8F9FE),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kBorder),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: color.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color.shade500, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: kInk,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11,
                      color: kGrey,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 12, color: Colors.grey.shade300),
          ],
        ),
      ),
    );
  }
}
