import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';

class ViewJoiningsScreen extends StatefulWidget {
  final String tournamentId;
  final String initialViewMode; // 'all' ya 'my'

  const ViewJoiningsScreen({
    super.key,
    required this.tournamentId,
    this.initialViewMode = 'all',
  });

  @override
  State<ViewJoiningsScreen> createState() => _ViewJoiningsScreenState();
}

class _ViewJoiningsScreenState extends State<ViewJoiningsScreen> {
  late String _viewMode;
  bool _loading = true;
  List<Map<String, dynamic>> _participants = [];

  @override
  void initState() {
    super.initState();
    _viewMode = widget.initialViewMode;
    _fetchJoinings();
  }

  Future<void> _fetchJoinings() async {
    setState(() => _loading = true);
    final user = Supabase.instance.client.auth.currentUser;

    try {
      // Simple select query without profiles join to prevent foreign key issues
      var query = Supabase.instance.client
          .from('participants')
          .select('id, team_no, position, ign, game_id, user_id')
          .eq('tournament_id', widget.tournamentId);

      if (_viewMode == 'my' && user != null) {
        query = query.eq('user_id', user.id);
      }

      final res = await query.order('id', ascending: true);

      if (res != null && mounted) {
        setState(() {
          _participants = List<Map<String, dynamic>>.from(res);
        });
      }
    } catch (_) {
      if (mounted) setState(() => _participants = []);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _switchView(String mode) {
    setState(() {
      _viewMode = mode;
    });
    _fetchJoinings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Pure White Background
      appBar: AppBar(
        backgroundColor: const Color(0xFF64748B), // Slate Grey Header
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_left_rounded, color: Colors.white, size: 28),
          onPressed: () {
            if (_viewMode == 'my') {
              _switchView('all');
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          _viewMode == 'my' ? 'YOUR JOININGS' : 'ALL JOININGS',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 0.5),
        ),
        actions: [
          if (_viewMode != 'my')
            Center(
              child: Container(
                margin: const EdgeInsets.only(right: 16),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.amber.shade500.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.amber.shade300.withOpacity(0.4)),
                ),
                child: Text(
                  'Total: ${_participants.length}',
                  style: const TextStyle(color: Color(0xFFFDE047), fontWeight: FontWeight.bold, fontSize: 11),
                ),
              ),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kIndigo))
          : _participants.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 60),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.group_off_rounded, size: 48, color: Color(0xFFCBD5E1)),
                        const SizedBox(height: 12),
                        Text(
                          _viewMode == 'my' ? 'You have not joined this contest yet!' : 'No participants found yet!',
                          style: const TextStyle(color: kGrey, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                )
              : SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width),
                    child: DataTable(
                      headingRowColor: WidgetStateProperty.all(const Color(0xFFF1F5F9)),
                      dataRowMinHeight: 48,
                      dataRowMaxHeight: 56,
                      columnSpacing: 24,
                      columns: const [
                        DataColumn(label: Text('Team No.', style: TextStyle(color: Color(0xFF475569), fontWeight: FontWeight.w900, fontSize: 11))),
                        DataColumn(label: Text('Pos.', style: TextStyle(color: Color(0xFF475569), fontWeight: FontWeight.w900, fontSize: 11))),
                        DataColumn(label: Text('In Game Name', style: TextStyle(color: Color(0xFF475569), fontWeight: FontWeight.w900, fontSize: 11))),
                        DataColumn(label: Text('In Game Id', style: TextStyle(color: Color(0xFF475569), fontWeight: FontWeight.w900, fontSize: 11))),
                      ],
                      rows: _participants.asMap().entries.map((entry) {
                        final index = entry.key;
                        final p = entry.value;
                        final teamNo = p['team_no'] ?? (index + 1);
                        final pos = p['position'] ?? '1';
                        final ign = p['ign'] ?? 'Player'; // Safe fallback
                        final igId = p['game_id'] ?? '-';

                        return DataRow(
                          cells: [
                            DataCell(Text('$teamNo', style: const TextStyle(color: Color(0xFF334155), fontWeight: FontWeight.bold, fontSize: 12))),
                            DataCell(Text('$pos', style: const TextStyle(color: Color(0xFFD97706), fontWeight: FontWeight.w900, fontSize: 12))),
                            DataCell(Text('$ign', style: const TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.bold, fontSize: 12))),
                            DataCell(Text('$igId', style: const TextStyle(color: Color(0xFF475569), fontWeight: FontWeight.w500, fontSize: 12))),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(12),
        color: Colors.white,
        child: _viewMode == 'my'
            ? SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF3498DB),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  onPressed: () => _switchView('all'),
                  child: const Text('BACK TO ALL JOININGS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                ),
              )
            : Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2ECC71),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          elevation: 0,
                        ),
                        onPressed: () => _switchView('my'),
                        child: const Text('MY ENTRIES', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: SizedBox(
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF3498DB),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          elevation: 0,
                        ),
                        onPressed: () => Navigator.pop(context),
                        child: const Text('SHOW DETAILS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
