import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../core/helpers.dart';
import '../core/theme.dart';

class EarnScreen extends StatefulWidget {
  const EarnScreen({super.key});

  @override
  State<EarnScreen> createState() => _EarnScreenState();
}

class _EarnScreenState extends State<EarnScreen> {
  static const String officialDownloadUrl = "https://kavoxarena.in";

  bool _loading = true;
  String _referralCode = '';
  int _totalReferrals = 0;
  int _qualifiedReferrals = 0;
  double _totalEarned = 0.0;
  double _pendingRewards = 0.0;
  List<Map<String, dynamic>> _myReferrals = [];

  @override
  void initState() {
    super.initState();
    _fetchReferralData();
  }

  Future<void> _fetchReferralData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('referral_code, referral_earnings')
          .eq('id', user.id)
          .maybeSingle();

      if (profile != null) {
        _referralCode = profile['referral_code'] ?? user.id.substring(0, 6).toUpperCase();
        _totalEarned = dbl(profile['referral_earnings']);
      } else {
        _referralCode = user.id.substring(0, 6).toUpperCase();
      }

      final referrals = await Supabase.instance.client
          .from('profiles')
          .select('id, username, created_at, is_qualified_referral')
          .eq('referred_by', user.id)
          .order('created_at', ascending: false);

      int qualifiedCount = 0;
      for (var r in referrals) {
        if (r['is_qualified_referral'] == true) qualifiedCount++;
      }

      if (mounted) {
        setState(() {
          _totalReferrals = referrals.length;
          _qualifiedReferrals = qualifiedCount;
          _myReferrals = List<Map<String, dynamic>>.from(referrals);
          _pendingRewards = 0;
        });
      }
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _maskName(String name) {
    if (name.length <= 2) return "${name[0]}***";
    return "${name.substring(0, 2)}***${name.substring(name.length - 1)}";
  }

  void _shareInvite() {
    final msg = """Join KAVOX ARENA - Play Free Fire Tournaments!

Use my referral code: $_referralCode
Download the app: $officialDownloadUrl

Sign up with my code and start winning!""";
    Share.share(msg);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text('Refer & Earn', style: TextStyle(color: kInk, fontWeight: FontWeight.bold, fontSize: 18)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kIndigo))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [kIndigo, Color(0xFF8B5CF6)]),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.card_giftcard, color: Colors.white, size: 36),
                        SizedBox(height: 12),
                        Text('Invite Friends & Earn Cash!', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                        SizedBox(height: 6),
                        Text('Get ₹10 for every friend who joins their first tournament using your referral code.', style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  Row(children: [
                    _summaryCard("TOTAL REFERRALS", "$_totalReferrals"),
                    const SizedBox(width: 12),
                    _summaryCard("QUALIFIED", "$_qualifiedReferrals"),
                  ]),
                  const SizedBox(height: 12),
                  Row(children: [
                    _summaryCard("TOTAL EARNED", "₹${_totalEarned.toStringAsFixed(0)}", isGreen: true),
                    const SizedBox(width: 12),
                    _summaryCard("PENDING", "₹${_pendingRewards.toStringAsFixed(0)}"),
                  ]),
                  const SizedBox(height: 24),

                  const Text('YOUR REFERRAL CODE', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(color: const Color(0xFFF8F9FE), borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(_referralCode, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kIndigo, letterSpacing: 1.5)),
                        ElevatedButton.icon(
                          onPressed: () {
                            Clipboard.setData(ClipboardData(text: _referralCode));
                            snack(context, 'Code copied!');
                          },
                          style: ElevatedButton.styleFrom(backgroundColor: kIndigo, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                          icon: const Icon(Icons.copy, size: 16),
                          label: const Text('Copy'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  const Text('DOWNLOAD KAVOX ARENA', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
                    child: Column(
                      children: [
                        Row(children: [
                          const Icon(Icons.link, size: 18, color: kIndigo),
                          const SizedBox(width: 8),
                          Expanded(child: Text(officialDownloadUrl, style: const TextStyle(fontSize: 13, color: kInk))),
                        ]),
                        const SizedBox(height: 10),
                        Row(children: [
                          Expanded(child: OutlinedButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: officialDownloadUrl)); snack(context, "Link copied!"); }, icon: const Icon(Icons.copy, size: 16), label: const Text("Copy Link"))),
                          const SizedBox(width: 10),
                          Expanded(child: ElevatedButton.icon(onPressed: _shareInvite, style: ElevatedButton.styleFrom(backgroundColor: kIndigo, foregroundColor: Colors.white), icon: const Icon(Icons.share, size: 16), label: const Text("Share App"))),
                        ]),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _shareInvite,
                      style: ElevatedButton.styleFrom(backgroundColor: kIndigo, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      child: const Text("SHARE INVITE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 24),

                  const Text('REFERRAL PROGRESS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                  const SizedBox(height: 12),
                  _progressLine(),
                  const SizedBox(height: 24),

                  const Text('MY REFERRALS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                  const SizedBox(height: 8),
                  _myReferrals.isEmpty
                      ? Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(color: const Color(0xFFF8F9FE), borderRadius: BorderRadius.circular(12), border: Border.all(color: kBorder)),
                          child: const Center(child: Text("No referrals yet — share your invite link to get started.", style: TextStyle(color: kGrey, fontSize: 13))),
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _myReferrals.length,
                          itemBuilder: (ctx, i) {
                            final r = _myReferrals[i];
                            final status = r['is_qualified_referral'] == true ? "Qualified" : "Registered";
                            final reward = r['is_qualified_referral'] == true ? "Reward Credited" : "Awaiting Qualification";
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(_maskName(r['username'] ?? "User"), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                              subtitle: Text("$status • $reward", style: const TextStyle(fontSize: 11, color: kGrey)),
                              trailing: Text(r['created_at'] != null ? r['created_at'].toString().substring(0, 10) : "", style: const TextStyle(fontSize: 11)),
                            );
                          },
                        ),
                  const SizedBox(height: 24),

                  const Text('HOW IT WORKS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                  const SizedBox(height: 12),
                  _stepItem('1', 'Share your unique referral code and download link with your friends.'),
                  _stepItem('2', 'Your friend signs up on KAVOX ARENA using your referral code.'),
                  _stepItem('3', 'Once your friend joins their first tournament, you receive ₹10 in your wallet.'),
                  const SizedBox(height: 24),

                  const Text('RULES & FAQs', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kGrey)),
                  const SizedBox(height: 12),
                  _faq("When will I get the reward?", "You will receive the reward as soon as your referred friend joins their first tournament."),
                  _faq("Can I refer myself?", "No, self-referrals are not allowed. Referrals from the same device or duplicate accounts will not be eligible."),
                  _faq("Will I get the reward multiple times for the same friend?", "No, you will receive the reward only once per friend."),
                  _faq("Need help?", "Contact us at kavoxarena.in for any support related to referrals."),
                ],
              ),
            ),
    );
  }

  Widget _summaryCard(String title, String value, {bool isGreen = false}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: const Color(0xFFF8F9FE), borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: kGrey)),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: isGreen ? const Color(0xFF059669) : kInk)),
        ]),
      ),
    );
  }

  Widget _progressLine() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _progressDot("Invited", true),
        _progressDot("Registered", _totalReferrals > 0),
        _progressDot("Qualified", _qualifiedReferrals > 0),
        _progressDot("Credited", _totalEarned > 0),
      ],
    );
  }

  Widget _progressDot(String label, bool active) {
    return Column(children: [
      Container(width: 18, height: 18, decoration: BoxDecoration(color: active ? kIndigo : kBorder, shape: BoxShape.circle)),
      const SizedBox(height: 4),
      Text(label, style: TextStyle(fontSize: 10, color: active ? kIndigo : kGrey)),
    ]);
  }

  Widget _stepItem(String num, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(children: [
        Container(width: 28, height: 28, alignment: Alignment.center, decoration: BoxDecoration(color: kIndigo.withOpacity(0.1), borderRadius: BorderRadius.circular(8)), child: Text(num, style: const TextStyle(fontWeight: FontWeight.bold, color: kIndigo, fontSize: 13))),
        const SizedBox(width: 14),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: kInk))),
      ]),
    );
  }

  Widget _faq(String q, String a) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(q, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: kInk)),
        const SizedBox(height: 2),
        Text(a, style: const TextStyle(fontSize: 12, color: kGrey)),
      ]),
    );
  }
}