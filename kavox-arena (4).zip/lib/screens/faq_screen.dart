import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme.dart';

class FaqScreen extends StatefulWidget {
  const FaqScreen({super.key});

  @override
  State<FaqScreen> createState() => _FaqScreenState();
}

class _FaqScreenState extends State<FaqScreen> {
  String _selectedCategory = 'all';

  final List<Map<String, dynamic>> _faqs = [
    {
      'category': 'prizes',
      'tag': 'Prizes',
      'icon': Icons.emoji_events,
      'iconColor': Colors.amber,
      'question': "Why didn't I receive my prizes?",
      'answers': [
        'Check the special notes of the previously joined match to verify if the gameplay recording was required.',
        'Ensure you haven\'t violated match rules & regulations, as this could result in prizes ineligibility.',
      ],
    },
    {
      'category': 'gameplay',
      'tag': 'Gameplay',
      'icon': Icons.sports_esports,
      'iconColor': Colors.blue,
      'question': 'When Should I Start Recording?',
      'answers': [
        'Before joining the custom room, start screen recording to provide evidence if you are removed from the room and need to request a refund.',
        'During the match, use in-game recording tools or a screen recorder for documentation.',
        'If suspicious gameplay is identified, Kavox Arena may request your recording. Only the screen recording will be considered valid evidence in such cases, not the in-game recording.',
      ],
    },
    {
      'category': 'matches',
      'tag': 'Matches',
      'icon': Icons.sports_kabaddi,
      'iconColor': Colors.purple,
      'question': 'Can I know the custom room settings of matches?',
      'answers': [
        'Yes, you can contact customer support to request the custom room settings.',
      ],
    },
    {
      'category': 'coins',
      'tag': 'Coins',
      'icon': Icons.monetization_on,
      'iconColor': Colors.green,
      'question': 'How can I earn and use bonus coins?',
      'answers': [
        'Earn bonus coins by referring your friends. When your friend joins their first paid match, you will receive 5 bonus coins.',
        'Use bonus coins to participate in matches.',
      ],
    },
    {
      'category': 'matches',
      'tag': 'Matches',
      'icon': Icons.sports_kabaddi,
      'iconColor': Colors.purple,
      'question': 'Can I know when matches are added?',
      'answers': [
        'No, there is no specific time for adding matches. They can be added at any time.',
      ],
    },
    {
      'category': 'support',
      'tag': 'Support',
      'icon': Icons.support_agent,
      'iconColor': Colors.pink,
      'question': 'What should I do if my prizes are not credited within the given time?',
      'answers': [
        'Contact customer support with the match details and proof of your win to get assistance.',
      ],
    },
    {
      'category': 'coins',
      'tag': 'Coins',
      'icon': Icons.monetization_on,
      'iconColor': Colors.green,
      'question': 'When will I receive my purchased coins?',
      'answers': [
        'Coins are usually credited within seconds to minutes.',
        'If there\'s a delay, contact customer support for help.',
      ],
    },
    {
      'category': 'matches',
      'tag': 'Matches',
      'icon': Icons.sports_kabaddi,
      'iconColor': Colors.purple,
      'question': 'How do I join a match?',
      'answers': [
        'Navigate to the matches section.',
        'Select your preferred match and follow the registration steps.',
        'Ensure you meet the eligibility criteria before joining.',
      ],
    },
    {
      'category': 'coins',
      'tag': 'Coins',
      'icon': Icons.monetization_on,
      'iconColor': Colors.green,
      'question': 'How do I withdraw my earnings?',
      'answers': [
        'Go to the wallet section.',
        'Select withdraw and provide the required details.',
        'The funds will be successfully transferred to your account within 1-2 hours.',
      ],
    },
  ];

  Future<void> _openUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $urlString');
    }
  }

  @override
  Widget build(BuildContext context) {
    final filteredFaqs = _selectedCategory == 'all'
        ? _faqs
        : _faqs.where((faq) => faq['category'] == _selectedCategory).toList();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kInk),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Frequently Asked Questions',
          style: TextStyle(
            color: kInk,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Category Filter Buttons (Grid 3x2)
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 2.6,
              children: [
                _filterButton('all', 'All', null, null),
                _filterButton('prizes', 'Prizes', Icons.emoji_events, Colors.amber),
                _filterButton('gameplay', 'Gameplay', Icons.sports_esports, Colors.blue),
                _filterButton('coins', 'Coins', Icons.monetization_on, Colors.green),
                _filterButton('matches', 'Matches', Icons.sports_kabaddi, Colors.purple),
                _filterButton('support', 'Support', Icons.support_agent, Colors.pink),
              ],
            ),
            const SizedBox(height: 16),

            // FAQ List Accordion Cards
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filteredFaqs.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final faq = filteredFaqs[index];
                return _FaqCard(
                  tag: faq['tag'],
                  icon: faq['icon'],
                  iconColor: faq['iconColor'],
                  question: faq['question'],
                  answers: List<String>.from(faq['answers']),
                );
              },
            ),
            const SizedBox(height: 16),

            // Still Need Help Box with Social Links
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FE),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kBorder),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: kIndigo.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.headset_mic_outlined, color: kIndigo, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'Still need help?',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: kInk),
                          ),
                          Text(
                            'Connect with our support team instantly.',
                            style: TextStyle(fontSize: 11, color: kGrey),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      // WhatsApp
                      Expanded(
                        child: _socialButton(
                          'WhatsApp',
                          Icons.chat,
                          Colors.green,
                          () => _openUrl('https://whatsapp.com/channel/0029VbDZBHt17Emzw6h7z30m'),
                        ),
                      ),
                      const SizedBox(width: 6),
                      // Instagram
                      Expanded(
                        child: _socialButton(
                          'Instagram',
                          Icons.camera_alt,
                          Colors.pink,
                          () => _openUrl('https://www.instagram.com/kavoxarena?igsi=ZzFhcDZhcGo0MmI5'),
                        ),
                      ),
                      const SizedBox(width: 6),
                      // Telegram
                      Expanded(
                        child: _socialButton(
                          'Telegram',
                          Icons.send,
                          Colors.lightBlue,
                          () => _openUrl('https://t.me/kavoxarena_support'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _filterButton(String category, String label, IconData? icon, Color? iconColor) {
    final isSelected = _selectedCategory == category;
    return InkWell(
      onTap: () => setState(() => _selectedCategory = category),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: isSelected ? kIndigo : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isSelected ? kIndigo : kBorder),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 14, color: isSelected ? Colors.white : iconColor),
              const SizedBox(width: 4),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: isSelected ? Colors.white : kInk,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _socialButton(String label, IconData icon, MaterialColor color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color.shade50,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.shade200),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 14, color: color.shade700),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(color: color.shade700, fontWeight: FontWeight.bold, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _FaqCard extends StatefulWidget {
  final String tag;
  final IconData icon;
  final Color iconColor;
  final String question;
  final List<String> answers;

  const _FaqCard({
    required this.tag,
    required this.icon,
    required this.iconColor,
    required this.question,
    required this.answers,
  });

  @override
  State<_FaqCard> createState() => _FaqCardState();
}

class _FaqCardState extends State<_FaqCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        children: [
          ListTile(
            onTap: () => setState(() => _expanded = !_expanded),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            leading: Container(
              width: 32,
              height: 32,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: widget.iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(widget.icon, color: widget.iconColor, size: 16),
            ),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  margin: const EdgeInsets.only(bottom: 4),
                  decoration: BoxDecoration(
                    color: widget.iconColor.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: widget.iconColor.withOpacity(0.2)),
                  ),
                  child: Text(
                    widget.tag,
                    style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: widget.iconColor),
                  ),
                ),
                Text(
                  widget.question,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kInk),
                ),
              ],
            ),
            trailing: Icon(
              _expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
              color: kGrey,
              size: 18,
            ),
          ),
          if (_expanded) ...[
            const Divider(height: 1, color: kBorder),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: widget.answers
                    .map(
                      (ans) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('• ', style: TextStyle(fontWeight: FontWeight.bold, color: kGrey)),
                            Expanded(
                              child: Text(
                                ans,
                                style: const TextStyle(fontSize: 12, color: kInk, height: 1.4),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
