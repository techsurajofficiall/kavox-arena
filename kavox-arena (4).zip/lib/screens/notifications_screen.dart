import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  final List<Map<String, dynamic>> _notifications = const [
    {
      'icon': Icons.security,
      'badge': 'Anti-Cheat',
      'badgeColor': Colors.red,
      'title': 'POV & Hacker Protection Policy 🚨',
      'message': 'To protect our players from hackers and cheaters, if a player is asked for POV (Screen Recording) 2 times and fails to provide it, their account will be permanently banned immediately!!',
    },
    {
      'icon': Icons.confirmation_number_outlined,
      'badge': 'Refund Policy',
      'badgeColor': Colors.purple,
      'title': 'Room Removal & Full Refund',
      'message': 'If you are removed from a room, you can receive a full refund by messaging customer support. Note: You must have a screen recording showing you were removed and registered under the exact same game name ID.',
    },
    {
      'icon': Icons.account_balance_wallet_outlined,
      'badge': 'Deposit Note',
      'badgeColor': Colors.amber,
      'title': 'Coin Addition & Payment Notice',
      'message': 'If coins are not credited to your wallet after successful payment, please contact customer support within 12 hours with valid payment proof to get your coins added instantly. Remember: valid only within 12 hours!',
    },
    {
      'icon': Icons.access_time,
      'badge': 'Timing',
      'badgeColor': Colors.blue,
      'title': 'Withdrawal Timings & Rules',
      'message': 'Withdrawal timing is strictly from 10:00 AM to 10:00 PM. Withdrawals are usually processed quickly, but may take up to 72 hours under rare circumstances.',
    },
    {
      'icon': Icons.card_giftcard,
      'badge': 'Smart Reward',
      'badgeColor': Colors.teal,
      'title': 'Daily 1v1 Loyalty Bonus (10 Coins)',
      'message': 'Great opportunity! If you play more than 10 matches daily strictly in 1v1 Lone Wolf or 1v1 Clash Squad modes, you can get a free bonus of 10 coins by contacting customer support. (Cancelled matches or empty slots do not count. Valid once per day per account).',
    },
  ];

  Future<void> _openUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $urlString');
    }
  }

  void _showSupportModal(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: const [
                Icon(Icons.support_agent, color: kIndigo, size: 20),
                SizedBox(width: 8),
                Text('Select Support Channel', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kInk)),
              ],
            ),
            IconButton(
              icon: const Icon(Icons.close, size: 18, color: kGrey),
              onPressed: () => Navigator.pop(ctx),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _supportOptionTile(
              'Telegram Support (Main)',
              'Fastest response via Telegram',
              Icons.send,
              Colors.lightBlue,
              () => _openUrl('https://t.me/kavoxarena_support'),
            ),
            const SizedBox(height: 8),
            _supportOptionTile(
              'Instagram Support',
              'Connect via Instagram DM',
              Icons.camera_alt,
              Colors.pink,
              () => _openUrl('https://www.instagram.com/kavoxarena?igsi=ZzFhcDZhcGo0MmI5'),
            ),
            const SizedBox(height: 8),
            _supportOptionTile(
              'WhatsApp Channel',
              'Join for updates & announcements',
              Icons.chat,
              Colors.green,
              () => _openUrl('https://whatsapp.com/channel/0029VbDZBHt17Emzw6h7z30m'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kInk),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Notifications & Rules',
          style: TextStyle(
            color: kInk,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Notifications List
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _notifications.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final item = _notifications[index];
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 32,
                                height: 32,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: kIndigo.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(item['icon'], color: kIndigo, size: 16),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                item['title'],
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: kInk),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: (item['badgeColor'] as MaterialColor).shade50,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: (item['badgeColor'] as MaterialColor).shade200),
                            ),
                            child: Text(
                              item['badge'],
                              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: (item['badgeColor'] as MaterialColor).shade700),
                            ),
                          ),
                        ],
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Divider(height: 1, color: kBorder),
                      ),
                      Text(
                        item['message'],
                        style: const TextStyle(fontSize: 12, color: kInk, height: 1.4),
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 16),

            // Support Quick Action Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF8F9FE),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kBorder),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: kIndigo.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.headset_mic_outlined, color: kIndigo, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Facing Any Issue?', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: kInk)),
                          Text('Our support team is here to help 24/7.', style: TextStyle(fontSize: 11, color: kGrey)),
                        ],
                      ),
                    ],
                  ),
                  ElevatedButton.icon(
                    onPressed: () => _showSupportModal(context),
                    icon: const Icon(Icons.support_agent, size: 14, color: Colors.white),
                    label: const Text('Support', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kIndigo,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _supportOptionTile(String title, String subtitle, IconData icon, MaterialColor color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.shade200),
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: color.shade600.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color.shade700, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: color.shade900)),
                  Text(subtitle, style: TextStyle(fontSize: 10, color: color.shade700)),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 12, color: color.shade700),
          ],
        ),
      ),
    );
  }
}
