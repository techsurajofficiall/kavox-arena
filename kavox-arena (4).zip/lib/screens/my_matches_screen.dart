import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';

class MyMatchesScreen extends StatefulWidget {
  final int initialTabIndex;
  const MyMatchesScreen({super.key, this.initialTabIndex = 0});

  @override
  State<MyMatchesScreen> createState() => _MyMatchesScreenState();
}

class _MyMatchesScreenState extends State<MyMatchesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _loading = true;
  List<dynamic> _upcoming = [];
  List<dynamic> _ongoing = [];
  List<dynamic> _completed = [];
  late RealtimeChannel _tournamentsChannel;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 3,
      vsync: this,
      initialIndex: widget.initialTabIndex < 3 ? widget.initialTabIndex : 0,
    );
    _fetchMyMatches();
    _setupRealtimeSubscription();
  }

  @override
  void dispose() {
    Supabase.instance.client.removeChannel(_tournamentsChannel);
    _tabController.dispose();
    super.dispose();
  }

  void _setupRealtimeSubscription() {
    _tournamentsChannel = Supabase.instance.client
        .channel('public:tournaments')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'tournaments',
          callback: (_) => _fetchMyMatches(isSilent: true),
        )
        .subscribe();
  }

  Future<void> _fetchMyMatches({bool isSilent = false}) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    try {
      final res = await Supabase.instance.client
          .from('participants')
          .select('*, tournaments(*)')
          .eq('user_id', user.id)
          .order('created_at', ascending: false);

      if (res != null && mounted) {
        final List<dynamic> up = [];
        final List<dynamic> on = [];
        final List<dynamic> comp = [];

        for (var item in res) {
          final t = item['tournaments'];
          if (t == null) continue;
          final s = (t['status'] ?? 'upcoming').toString().toLowerCase();
          if (s == 'live' || s == 'ongoing') {
            on.add(item);
          } else if (s == 'completed' || s == 'finished') {
            comp.add(item);
          } else {
            up.add(item);
          }
        }

        setState(() {
          _upcoming = up;
          _ongoing = on;
          _completed = comp;
          if (!isSilent) _loading = false;
        });
      }
    } catch (_) {
      if (!isSilent && mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kInk),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'My Matches',
          style: TextStyle(color: kInk, fontWeight: FontWeight.bold, fontSize: 18),
        ),
        bottom: TabBar(
          controller: _tabController,
          labelColor: kIndigo,
          unselectedLabelColor: kGrey,
          indicatorColor: kIndigo,
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
          tabs: const [
            Tab(text: 'UPCOMING'),
            Tab(text: 'ONGOING'),
            Tab(text: 'COMPLETED'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kIndigo))
          : TabBarView(
              controller: _tabController,
              children: [
                _buildMatchList(_upcoming, isOngoing: false, isCompleted: false),
                _buildMatchList(_ongoing, isOngoing: true, isCompleted: false),
                _buildMatchList(_completed, isOngoing: false, isCompleted: true),
              ],
            ),
    );
  }

  Widget _buildMatchList(List<dynamic> list, {required bool isOngoing, required bool isCompleted}) {
    if (list.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isOngoing
                  ? Icons.autorenew
                  : (isCompleted ? Icons.emoji_events_outlined : Icons.sports_esports_outlined),
              size: 60,
              color: kGrey.withOpacity(0.5),
            ),
            const SizedBox(height: 12),
            Text(
              isOngoing
                  ? 'No Ongoing Matches Currently'
                  : (isCompleted ? 'No Completed Matches Yet' : 'No Upcoming Matches Joined'),
              style: const TextStyle(color: kGrey, fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => _fetchMyMatches(),
      color: kIndigo,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: list.length,
        itemBuilder: (ctx, i) {
          final item = list[i];
          final t = item['tournaments'] ?? {};
          final title = t['title'] ?? 'Tournament';
          final matchTime = t['start_time'] ?? 'TBA';
          final roomId = t['room_id'] ?? '';
          final roomPass = t['room_password'] ?? '';
          final myIgn = item['ign'] ?? 'Player';
          final mySlot = item['slot_no'] ?? '-';
          final userKills = item['kills'] ?? 0;
          final userWinnings = dbl(item['winnings']);

          return Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: isOngoing ? kIndigo : kBorder, width: isOngoing ? 1.5 : 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: kInk),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (isOngoing)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: kRed.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: const [
                            CircleAvatar(radius: 4, backgroundColor: kRed),
                            SizedBox(width: 6),
                            Text('ONGOING', style: TextStyle(color: kRed, fontWeight: FontWeight.bold, fontSize: 11)),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),

                Row(
                  children: [
                    Text('IGN: $myIgn', style: const TextStyle(fontSize: 12, color: kGrey, fontWeight: FontWeight.w500)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: kIndigo.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        'SLOT #$mySlot',
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kIndigo),
                      ),
                    ),
                  ],
                ),
                const Divider(height: 20, color: kBorder),

                if (isOngoing) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8F9FE),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: kBorder),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'ROOM ID: ${roomId.isEmpty ? 'Waiting...' : roomId}',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                color: roomId.isEmpty ? kGrey : kInk,
                              ),
                            ),
                            if (roomId.isNotEmpty)
                              GestureDetector(
                                onTap: () {
                                  Clipboard.setData(ClipboardData(text: roomId));
                                  snack(context, 'Room ID Copied!');
                                },
                                child: const Icon(Icons.copy, color: kIndigo, size: 18),
                              ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'PASS: ${roomPass.isEmpty ? 'Waiting...' : roomPass}',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                color: roomPass.isEmpty ? kGrey : kInk,
                              ),
                            ),
                            if (roomPass.isNotEmpty)
                              GestureDetector(
                                onTap: () {
                                  Clipboard.setData(ClipboardData(text: roomPass));
                                  snack(context, 'Room Password Copied!');
                                },
                                child: const Icon(Icons.copy, color: kIndigo, size: 18),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],

                if (!isOngoing && !isCompleted) ...[
                  Row(
                    children: [
                      const Icon(Icons.access_time_rounded, size: 16, color: kIndigo),
                      const SizedBox(width: 6),
                      Text('Starts at: $matchTime', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: kInk)),
                    ],
                  ),
                ],

                if (isCompleted) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.sports_score, size: 16, color: kGrey),
                          const SizedBox(width: 6),
                          Text('Kills: $userKills', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: kInk)),
                        ],
                      ),
                      Text(
                        'Won: ₹${userWinnings.toStringAsFixed(0)}',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF059669)),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}
