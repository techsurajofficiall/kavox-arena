import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/helpers.dart';
import '../core/theme.dart';
import 'login_screen.dart';

class ProfileScreen extends StatefulWidget {
  final Function(int)? onAvatarChanged;
  const ProfileScreen({super.key, this.onAvatarChanged});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _ignController = TextEditingController();
  final _currentPassC = TextEditingController();
  final _newPassC = TextEditingController();
  final _reNewPassC = TextEditingController();
  
  String _username = '';
  String _email = '';
  String _phone = '';
  String _referralCode = '';
  String _securityCode = '';
  int _selectedAvatarIndex = 0;
  bool _loading = true;
  bool _savingIgn = false;
  bool _changingPass = false;
  int _totalDeposit = 0;

  final List<Map<String, dynamic>> _avatars = [
    {'icon': Icons.sports_esports, 'color': const Color(0xFF6366F1)},
    {'icon': Icons.face, 'color': const Color(0xFF8B5CF6)},
    {'icon': Icons.local_fire_department, 'color': const Color(0xFFF97316)},
    {'icon': Icons.rocket_launch, 'color': const Color(0xFF06B6D4)},
    {'icon': Icons.bolt, 'color': const Color(0xFFD97706)},
    {'icon': Icons.shield, 'color': const Color(0xFF059669)},
  ];

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  @override
  void dispose() {
    _ignController.dispose();
    _currentPassC.dispose();
    _newPassC.dispose();
    _reNewPassC.dispose();
    super.dispose();
  }

  String get _vipLevel {
    if (_totalDeposit >= 5000) return 'VIP 5';
    if (_totalDeposit >= 2000) return 'VIP 4';
    if (_totalDeposit >= 500) return 'VIP 3';
    if (_totalDeposit >= 100) return 'VIP 2';
    return 'VIP 1';
  }

  Color get _vipColor {
    if (_totalDeposit >= 5000) return const Color(0xFFFFD700);
    if (_totalDeposit >= 2000) return const Color(0xFF9C27B0);
    if (_totalDeposit >= 500) return const Color(0xFFE91E63);
    if (_totalDeposit >= 100) return const Color(0xFF2196F3);
    return kGrey;
  }

  Future<void> _loadProfileData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    try {
      final res = await Supabase.instance.client
          .from('profiles')
          .select('username, ign, referral_code, avatar_index, phone, security_code, total_deposit')
          .eq('id', user.id)
          .maybeSingle();

      if (res != null && mounted) {
        setState(() {
          _username = res['username'] ?? 'Gamer';
          _email = user.email ?? '';
          _phone = res['phone'] ?? '';
          _ignController.text = res['ign'] ?? '';
          _referralCode = res['referral_code'] ?? user.id.substring(0, 8).toUpperCase();
          _selectedAvatarIndex = res['avatar_index'] ?? 0;
          _securityCode = res['security_code'] ?? '';
          _totalDeposit = (res['total_deposit'] ?? 0) as int;
        });
      }
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveIgn() async {
    final newIgn = _ignController.text.trim();
    if (newIgn.isEmpty) {
      snack(context, 'Please enter Free Fire UID');
      return;
    }
    setState(() => _savingIgn = true);
    try {
      final user = Supabase.instance.client.auth.currentUser;
      await Supabase.instance.client.from('profiles').update({'ign': newIgn}).eq('id', user!.id);
      if (mounted) snack(context, 'FF UID saved!');
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _savingIgn = false);
    }
  }

  Future<void> _updateAvatar(int index) async {
    setState(() => _selectedAvatarIndex = index);
    Navigator.pop(context);
    if (widget.onAvatarChanged != null) widget.onAvatarChanged!(index);
    try {
      final user = Supabase.instance.client.auth.currentUser;
      await Supabase.instance.client.from('profiles').update({'avatar_index': index}).eq('id', user!.id);
    } catch (e) {
      if (mounted) snack(context, 'Failed to sync avatar');
    }
  }

  void _showAvatarPicker() {
    showDialog(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Choose avatar', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: kInk)),
        content: SizedBox(
          width: double.maxFinite,
          child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12),
            itemCount: _avatars.length,
            itemBuilder: (ctx, i) {
              final avatar = _avatars[i];
              final isSel = _selectedAvatarIndex == i;
              return GestureDetector(
                onTap: () => _updateAvatar(i),
                child: Container(
                  decoration: BoxDecoration(color: avatar['color'], shape: BoxShape.circle, border: isSel ? Border.all(color: kInk, width: 3) : null),
                  child: Icon(avatar['icon'], color: Colors.white, size: 28),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  // CHANGE PASSWORD WITH CURRENT PASS
  Future<void> _updatePassword() async {
    if (_currentPassC.text.isEmpty || _newPassC.text.isEmpty || _reNewPassC.text.isEmpty) {
      snack(context, 'All fields required');
      return;
    }
    if (_newPassC.text != _reNewPassC.text) {
      snack(context, 'New passwords do not match');
      return;
    }
    setState(() => _changingPass = true);
    try {
      // Verify current password by re-login
      await Supabase.instance.client.auth.signInWithPassword(email: _email, password: _currentPassC.text);
      await Supabase.instance.client.auth.updateUser(UserAttributes(password: _newPassC.text));
      if (mounted) {
        snack(context, 'Password updated successfully');
        _currentPassC.clear(); _newPassC.clear(); _reNewPassC.clear();
      }
    } catch (e) {
      if (mounted) snack(context, 'Current password galat hai: ${errText(e)}');
    } finally {
      if (mounted) setState(() => _changingPass = false);
    }
  }

  // FORGOT PASSWORD WITH SECURITY CODE - AFTER PERSONAL INFO
  void _showForgotWithSecurity() {
    final uNameC = TextEditingController(text: _username);
    final emailC = TextEditingController(text: _email);
    final phoneC = TextEditingController(text: _phone);
    final secCodeC = TextEditingController();
    final newPassC = TextEditingController();
    final confirmPassC = TextEditingController();
    bool verified = false;
    String? resetUserId;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheetState) {
          return Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 20, right: 20, top: 20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Reset with Security Code', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 15),
                  if (!verified) ...[
                    TextField(controller: uNameC, decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder())),
                    const SizedBox(height: 10),
                    TextField(controller: emailC, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
                    const SizedBox(height: 10),
                    TextField(controller: phoneC, decoration: const InputDecoration(labelText: 'Mobile No.', border: OutlineInputBorder())),
                    const SizedBox(height: 10),
                    TextField(controller: secCodeC, decoration: const InputDecoration(labelText: 'Security Code (Withdrawal Code)', border: OutlineInputBorder())),
                    const SizedBox(height: 15),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: kIndigo),
                        onPressed: () async {
                          try {
                            final res = await Supabase.instance.client.from('profiles').select('id').eq('username', uNameC.text.trim()).eq('phone', phoneC.text.trim()).eq('security_code', secCodeC.text.trim()).maybeSingle();
                            if (res != null) {
                              setSheetState(() { verified = true; resetUserId = res['id']; });
                            } else {
                              snack(ctx, 'Details galat hain, check karo');
                            }
                          } catch (e) {
                            snack(ctx, errText(e));
                          }
                        },
                        child: const Text('VERIFY', style: TextStyle(color: Colors.white)),
                      ),
                    ),
                  ] else ...[
                    TextField(controller: newPassC, obscureText: true, decoration: const InputDecoration(labelText: 'New Password', border: OutlineInputBorder())),
                    const SizedBox(height: 10),
                    TextField(controller: confirmPassC, obscureText: true, decoration: const InputDecoration(labelText: 'Re-enter New Password', border: OutlineInputBorder())),
                    const SizedBox(height: 15),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: kIndigo),
                        onPressed: () async {
                          if (newPassC.text != confirmPassC.text) { snack(ctx, 'Password match nahi'); return; }
                          try {
                            // Ye RPC Supabase me banana padega - jo maine pehle diya tha
                            await Supabase.instance.client.rpc('reset_password_with_code', params: {'p_user_id': resetUserId, 'p_new_password': newPassC.text});
                            if (ctx.mounted) { Navigator.pop(ctx); snack(context, 'Password reset ho gaya!'); }
                          } catch (e) {
                            snack(ctx, errText(e));
                          }
                        },
                        child: const Text('SET NEW PASSWORD', style: TextStyle(color: Colors.white)),
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        });
      },
    );
  }

  Future<void> _logout() async {
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    final currentAvatar = _avatars[_selectedAvatarIndex < _avatars.length ? _selectedAvatarIndex : 0];
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: kInk), onPressed: () => Navigator.pop(context)),
        title: const Text('Profile', style: TextStyle(color: kInk, fontWeight: FontWeight.bold, fontSize: 18)),
      ),
      body: _loading ? const Center(child: CircularProgressIndicator(color: kIndigo)) :
      SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          children: [
            Center(
              child: Stack(
                children: [
                  Container(width: 100, height: 100, decoration: BoxDecoration(color: currentAvatar['color'], shape: BoxShape.circle), child: Icon(currentAvatar['icon'], color: Colors.white, size: 50)),
                  Positioned(bottom: 0, right: 0, child: GestureDetector(onTap: _showAvatarPicker, child: Container(padding: const EdgeInsets.all(8), decoration: const BoxDecoration(color: kIndigo, shape: BoxShape.circle), child: const Icon(Icons.edit, color: Colors.white, size: 16)))),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(_username, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: kInk)),
            const SizedBox(height: 4),
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: _vipColor.withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: _vipColor)), child: Text(_vipLevel, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: _vipColor))),
            const SizedBox(height: 4),
            Text(_email, style: const TextStyle(fontSize: 12, color: kGrey)),
            const SizedBox(height: 25),
            const Align(alignment: Alignment.centerLeft, child: Text('IN-GAME NAME (FF UID)', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kIndigo))),
            const SizedBox(height: 8),
            Container(padding: const EdgeInsets.symmetric(horizontal: 14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder)), child: TextField(controller: _ignController, decoration: const InputDecoration(border: InputBorder.none, prefixIcon: Icon(Icons.sports_esports, color: kGrey), hintText: 'Enter Free Fire UID', hintStyle: TextStyle(color: kGrey, fontSize: 13)))),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, height: 48, child: ElevatedButton(onPressed: _savingIgn ? null : _saveIgn, style: ElevatedButton.styleFrom(backgroundColor: kIndigo, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)), elevation: 0), child: _savingIgn ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text('SAVE', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white)))),
            const SizedBox(height: 24),
            const Align(alignment: Alignment.centerLeft, child: Text('REFERRAL CODE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kIndigo))),
            const SizedBox(height: 8),
            Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_referralCode, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.2, color: kInk)), GestureDetector(onTap: () { Clipboard.setData(ClipboardData(text: _referralCode)); snack(context, 'Referral Code Copied!'); }, child: const Icon(Icons.copy_rounded, color: kIndigo, size: 20))])),
            const SizedBox(height: 24),

            // ===== YAHI PE TERA NAYA FORGET + CHANGE PASSWORD SYSTEM =====
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: kBorder)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('SECURITY & PASSWORD', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kIndigo)),
                  const SizedBox(height: 12),
                  TextField(controller: _currentPassC, obscureText: true, decoration: InputDecoration(labelText: 'Current Password', border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12))),
                  const SizedBox(height: 10),
                  TextField(controller: _newPassC, obscureText: true, decoration: InputDecoration(labelText: 'New Password', border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12))),
                  const SizedBox(height: 10),
                  TextField(controller: _reNewPassC, obscureText: true, decoration: InputDecoration(labelText: 'Re-enter New Password', border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12))),
                  const SizedBox(height: 14),
                  SizedBox(width: double.infinity, height: 44, child: ElevatedButton(onPressed: _changingPass ? null : _updatePassword, style: ElevatedButton.styleFrom(backgroundColor: kIndigo, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))), child: _changingPass ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text('UPDATE PASSWORD', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))),
                  const SizedBox(height: 10),
                  Center(child: TextButton(onPressed: _showForgotWithSecurity, child: const Text('Forgot password? Reset with Security Code', style: TextStyle(color: kIndigo, fontSize: 12)))),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(width: double.infinity, height: 50, child: OutlinedButton.icon(onPressed: _logout, icon: const Icon(Icons.logout, color: kRed, size: 20), label: const Text('LOGOUT', style: TextStyle(color: kRed, fontWeight: FontWeight.bold, fontSize: 14)), style: OutlinedButton.styleFrom(side: const BorderSide(color: kRed, width: 1.5), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)), backgroundColor: Colors.white))),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}