import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide toInt;

import 'core/theme.dart';
import 'screens/login_screen.dart';
import 'screens/root_screen.dart';

const supabaseUrl = 'https://fugkwuxzpjgbegdqpduq.supabase.co';
const supabaseAnonKey = 'sb_publishable_9Ov2S-TSC7fW7WdxLOHb4Q_CVJjFmY_';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const KvxApp());
}

class KvxApp extends StatelessWidget {
  const KvxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KAVOX ARENA',
      debugShowCheckedModeBanner: false,
      theme: kvxTheme(),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Supabase.instance.client.auth;
    return StreamBuilder<AuthState>(
      stream: auth.onAuthStateChange,
      builder: (context, snap) {
        final session = snap.data?.session ?? auth.currentSession;
        return session == null ? const LoginScreen() : const RootScreen();
      },
    );
  }
}